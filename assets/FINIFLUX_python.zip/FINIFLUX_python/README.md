# FINIFLUX (differentiable Python edition)

A **differentiable (autodiff) reimplementation** of the FINIFLUX radon mass-balance model
for estimating **groundwater discharge** and **hyporheic exchange** to rivers from
**radon-222 (²²²Rn)** profiles. The entire forward model — steady-state 1-D
advection–reaction transport solved with an implicit **Petrov–Galerkin (upwinded) linear
finite-element** scheme — is built from differentiable tensor operations. This **replaces
the external BEOPEST optimizer** of the original MATLAB code: gradients of the data-misfit
with respect to the parameters come from backpropagation, so the inversion optimizes
directly.

It ships as **two parallel packages** with identical physics, I/O contract, and outputs —
only the tensor backend and optimizer differ:

- [`finiflux_pytorch/`](finiflux_pytorch/) — **PyTorch** backend (Adam warm-start → L-BFGS).
- [`finiflux_tensorflow/`](finiflux_tensorflow/) — **TensorFlow** backend (Adam via `GradientTape`).

The model estimates, **per reach**: groundwater inflow `I`, hyporheic-zone depth `h`, and
hyporheic-zone mean residence time `t_h`.

## Authors

- **Sven Frei** — sven.frei@wur.nl
- **Benjamin S. Gilfedder** — gilfedder@uni-trier.de

## Background & references

Radon-222 is a naturally occurring, conservative groundwater tracer: groundwater is
strongly enriched in radon relative to river water, so the longitudinal radon profile along
a stream records where and how much groundwater enters. By closing a radon mass balance
reach by reach — accounting for groundwater inflow, hyporheic exchange, atmospheric
degassing, radioactive decay, and tributary inflow — FINIFLUX inverts the measured radon
profile into a spatially resolved estimate of groundwater discharge.

- Frei, S. & Gilfedder, B.S. (2015). *FINIFLUX: An implicit finite element model for
  quantification of groundwater fluxes and hyporheic exchange in streams and rivers using
  radon.*
  **Water Resources Research**, 51, 6776–6786.
  [doi:10.1002/2015WR017212](https://doi.org/10.1002/2015WR017212)
- Frei, S., Durejka, S., Le Lay, H., Thomas, Z. & Gilfedder, B.S. (2019). *Quantification
  of hyporheic nitrate removal at the reach scale: Exposure times versus residence times.*
  **Water Resources Research**, 55(11), 9808–9825.
  [doi:10.1029/2019WR025540](https://doi.org/10.1029/2019WR025540)

## Installation

Requires Python 3 with NumPy, openpyxl, matplotlib, and **one** tensor backend:

```bash
# PyTorch backend
pip install torch numpy openpyxl matplotlib

# or TensorFlow backend (use an arch-matched wheel, e.g. arm64 on Apple Silicon)
pip install tensorflow numpy openpyxl matplotlib
```

No editable install is required — the launcher puts the chosen package on `sys.path`.

## Quick start

[`run_FINIFLUX.py`](run_FINIFLUX.py) at the repository root is **the only file you execute**.
It locates `FINIFLUX.xlsx`, selects the backend, reads input, runs the model, writes the
output files, and makes the plots.

```bash
python run_FINIFLUX.py                       # invert, PyTorch, reads FINIFLUX.xlsx -> results/
python run_FINIFLUX.py --backend tensorflow  # same via TensorFlow
python run_FINIFLUX.py --mode forward        # one forward run, no fitting
python run_FINIFLUX.py --input other.xlsx --out run2 --show
python run_FINIFLUX.py --uncertainty --rn-sigma-rel 0.1   # fit + posterior UQ, 10% meas. σ
python run_FINIFLUX.py --endmember           # add GW-endmember uncertainty band
python run_FINIFLUX.py --bedform-depth       # compute h from bedform heights (col N)
```

Defaults live in the `CONFIG` dict at the top of the launcher; every entry has a matching
CLI flag (`--backend/--mode/--out/--plot/--show/--adam/--lbfgs/--iter/--lr/--smooth/--quiet`,
plus the uncertainty, endmember, and bedform flags).

Each package can also be driven directly or used as a library:

```bash
python -m finiflux_torch.cli invert FINIFLUX.xlsx
python -m finiflux_tf.cli    invert FINIFLUX.xlsx
```

```python
from finiflux_torch import read_input, fit, write_results, plot_all, estimate_uncertainty
data   = read_input("FINIFLUX.xlsx")
result = fit(data)
write_results(result, "results/")
```

## Governing equation (steady state, per reach)

```
Q dC/dx = [ I·c_gw + α1 + (Q_in/L)·c_in ]            (sources)
        − [ I + α2 + k·w + λ·d·w + Q_in/L ]·C        (sinks ∝ C)
```

where `C` is radon [Bq/m³], `Q` discharge [m³/s], `w` width, `d` depth,
`λ = 0.18/86400 s⁻¹` the ²²²Rn decay constant, `c_gw` the groundwater endmember, and
`Q_in, L, c_in` the tributary inflow rate, length and concentration.

- **Hyporheic source/loss** `α1` (production) and `α2` (loss ∝ `C`) depend on `h, por, w,
  t_h` and the residence-time distribution (RTD).
- **Degassing** `k` from O'Connor & Dobbins (1958), Negulescu & Rojanski (1969), or
  user-supplied values.

### Finite-element model

Linear (P1) elements; per element a reaction (consistent mass) matrix, a Galerkin advection
matrix, a **Petrov–Galerkin upwind** correction scaled by `β`, and a load vector are
assembled by vectorized scatter-add into dense `A`/`b` tensors. The **upstream Dirichlet
boundary** `C(node₁) = Rn(node₁)` is imposed by the penalty trick, and the system is solved
with `torch.linalg.solve` / `tf.linalg.solve` — **autograd flows through the solve**.

### RTD models

All three are implemented and reduce to a smooth `(α1, α2)` so gradients flow to `h, t_h`:

- **Exponential** — closed form `α1 = γ·h·w·por/(1+λ·t_h)`, `α2 = λ·h·w·por/(1+λ·t_h)`.
- **Gamma** — closed-form Laplace transform `L = (1+λ·t_h/a)^−a` (shape `a`).
- **Truncated power-law** — differentiable quadrature (faithful port of the MATLAB `pwr.m`).

## Inverse problem (autodiff)

- **Unknowns** (per reach, held in log space for positivity & scaling):
  `θ = (log I, log h, log t_h)`.
- **Loss** `L = data_misfit + reg`:
  - `data_misfit = Σ_nodes w_j·(C − Rn_obs)²` with **detection-limit-normalized weights**
    `w_j = 1/max(Rn_obs_j, detection_limit)²`, so large and small activities contribute
    comparably.
  - `reg` (configurable, small/zero by default): a **smoothness** penalty across adjacent
    reaches and/or a light **prior-anchor** toward the initial values.
- **Parameter bounds** enforced by clamping the log-params each iteration:
  `I ∈ [1e-10, 1e-2] m³/(m·s)`, `h ∈ [1e-3, 1.0] m`, `t_h ∈ [60, 43200] s`.
- **Optimizer:** PyTorch uses Adam warm-start → L-BFGS; TensorFlow uses Adam (Keras has no
  L-BFGS).

> **Why differentiable?** In native FINIFLUX, Tikhonov regularization toward priors is
> BEOPEST's stabilization mechanism. Here the regularization is **our design choice**, not a
> PEST copy — log-space parameters and the normalized misfit do the stabilizing, and the
> smoothness/prior penalties default small so the data drive the fit.

## Uncertainty quantification (`uncertainty.py`)

A separate, optional add-on (does not touch `forward.py`/`inverse.py`) builds the **Laplace
/ Gauss–Newton posterior covariance** of the fitted parameters on top of the same
differentiable forward model.

- Treats the calibrated `θ` as the MAP of a Gaussian-noise inverse problem; `Σ = H(θ̂)⁻¹`.
- `method="gauss_newton"` (default, PSD) builds `H ≈ Jᵀ Σ⁻¹ J + prior`; `method="full"` uses
  the exact autodiff Hessian.
- Noise model `σ` defaults to `max(obs, detection_limit)`; override with a known measurement
  σ (`--rn-sigma-abs/-rel`). `calibrate_sigma=True` rescales by `χ²/(N−p)`.
- Outputs per-reach `map/std/ci_low/ci_high`, a `.summary()`, a `.correlation()`, and an
  `identifiability_report()` exposing the `I`/`h`/`t_h` **equifinality** as near-zero Hessian
  eigenvalues.

```python
from finiflux_torch import estimate_uncertainty, UncertaintyConfig
unc = estimate_uncertainty(data, result, config=UncertaintyConfig())
```

## Groundwater-endmember uncertainty (`endmember.py`)

A second, independent error source — the GW endmember `c_gw`, usually the dominant
uncertainty in radon inflow estimates. **Column U** of `FINIFLUX.xlsx` holds the per-reach
endmember standard deviation. `endmember_uncertainty(data, config, p_low, p_high)` **re-fits
the inversion** at the low and high percentile endmembers (a higher endmember implies *less*
inflow for the same observed radon) and returns the resulting per-reach `I` envelope.
Percentiles are user-adjustable (`--em-p-low/--em-p-high`). Rendered as its own second figure.

## Hyporheic depth from bedforms (`bedform.py`, optional)

Instead of estimating `h`, `--bedform-depth` **computes** `h` per reach from bedform heights
via the Elliott & Brooks (1997, after Fehlman 1985) dynamic-head relation
`h_m = 0.28·(Ū²/2g)·(H/0.34d)^m`. **Column N is reinterpreted as the bedform height `H`**.
`h` becomes deterministic (frozen, no gradients), so the inversion fits **only `I` and
`t_h`**.

## Input file — `FINIFLUX.xlsx`

A single sheet, parsed **by label / column letter** (robust to row position, flexible
length `N`):

- **OPTIONS (cols B/C):** degassing model, hyporheic on/off, RTD model, gamma `alpha`,
  upstream weighting `β`, initial/upstream Rn (BC), detection limit.
- **Nodes (F, G):** location [m], measured radon [Bq/m³] — variable length `N_nodes`. Every
  node is a measurement location; modeled nodal `C` is compared 1:1 to the observations.
- **Reaches (I–T):** reach length, depth, width, GW endmember, HZ depth/bedform height,
  porosity, tributary discharge/length/conc, discharge, user `k` — length
  `N_reaches = N_nodes − 1`.
- **Col U (optional):** per-reach GW endmember standard deviation (drives the endmember
  analysis).

## Outputs

Per run (in `--out`): `gw_inflow.dat` (`I`), `depth_hz.dat` (`h`), `rtimes_hz.dat` (`t_h`),
and `Rn_modeled.csv` (x, modeled radon). With `--uncertainty`, also `uncertainty.csv`; with
`--endmember`, a second figure plus `endmember_uncertainty.csv`.

The main figure `finiflux_plots.png` stacks five panels:

1. simulated vs observed radon with r/RMSE (plus a shaded ±σ envelope when a known
   measurement σ is supplied);
2–4. estimated `I`, `h`, `t_h` per reach in space, each with a shaded credible-interval band;
5. cumulative groundwater inflow `Σ(I_i·Δx_i)` vs distance overlaid with the observed
   discharge gain `ΔQ` (water-balance check), with a credible band propagated from the `logI`
   covariance.

When uncertainty bands are drawn, the parameter panels set their y-range from the
**best-estimate values**, so a poorly-constrained interval cannot squash the estimate curve
flat — exact bounds live in `uncertainty.csv`.

## Package layout

```
run_FINIFLUX.py              # SINGLE LAUNCHER: backend select, run, write, plot

finiflux_pytorch/finiflux_torch/
  io.py            # label-based FINIFLUX.xlsx reader + native writers (pure NumPy/openpyxl)
  degassing.py     # k models 1/2/3
  hyporheic.py     # α1/α2 for exp + gamma + power-law RTD (differentiable)
  forward.py       # FE assemble + penalty BC + linear solve -> C (autodiff)
  inverse.py       # log-params, normalized misfit + reg, Adam -> L-BFGS
  uncertainty.py   # Laplace / Gauss-Newton posterior covariance (add-on)
  endmember.py     # GW-endmember (c_gw) uncertainty via percentile re-fits
  bedform.py       # Elliott-Brooks hyporheic depth h from bedform height H
  plotting.py      # plot_radon / plot_parameters / plot_uncertainty / plot_cumulative_gw
  cli.py           # python -m finiflux_torch.cli forward|invert
  tests/test_smoke.py

finiflux_tensorflow/finiflux_tf/   # line-for-line mirror; tf.scatter_nd + tf.linalg.solve,
                                    # tf.GradientTape + Keras Adam
```

`plotting.py` and `io.py` are framework-agnostic (pure NumPy) and identical across both
packages; `uncertainty.py` shares an identical API/statistics — only the autodiff backend
differs.

## Publications using FINIFLUX

Published studies that applied FINIFLUX (non-exhaustive; ordered by year):

- Pittroff, M., Frei, S. & Gilfedder, B.S. (2017). *Quantifying nitrate and oxygen reduction
  rates in the hyporheic zone using ²²²Rn to upscale biogeochemical turnover in rivers.*
  **Water Resources Research**, 53.
  [doi:10.1002/2016WR018917](https://doi.org/10.1002/2016WR018917)
- Schubert, M., Knöller, K., Müller, C. & Gilfedder, B. (2020). *Investigating river
  water/groundwater interaction along a rivulet section by ²²²Rn mass balancing.*
  **Water**, 12(11), 3027.
  [doi:10.3390/w12113027](https://doi.org/10.3390/w12113027)
- Schubert, M. et al. (2020). *Investigating groundwater discharge into a major river under
  low flow conditions based on a radon mass balance supported by tritium data* (River Elbe).
  **Water**, 12(10), 2838.
  [doi:10.3390/w12102838](https://doi.org/10.3390/w12102838)
- Frei, S., Wismeth, F. & Gilfedder, B.S. (2020). *Quantifizierung lokaler Grundwassereintritte
  in die Spree und deren Bedeutung für die Verockerungsproblematik in der Lausitz.*
  **Grundwasser**, 25, 231–241.
  [doi:10.1007/s00767-020-00452-0](https://doi.org/10.1007/s00767-020-00452-0)
- Kaule, R. & Gilfedder, B.S. (2021). *Groundwater dominates water fluxes in a headwater
  catchment during drought* (Mähringsbach). **Frontiers in Water**, 3, 706932.
  [doi:10.3389/frwa.2021.706932](https://doi.org/10.3389/frwa.2021.706932)
- Jimenez-Fernandez, O., Schwientek, M., Osenbrück, K., Glaser, C., Schmidt, C. &
  Fleckenstein, J.H. (2022). *Groundwater-surface water exchange as key control for instream
  and groundwater nitrate concentrations along a first-order agricultural stream.*
  **Hydrological Processes**, 36(2), e14507.
  [doi:10.1002/hyp.14507](https://doi.org/10.1002/hyp.14507)
- Adyasari, D., Dimova, N.T., Dulai, H., Gilfedder, B.S., Cartwright, I., McKenzie, T. &
  Fuleky, P. (2023). *Radon-222 as a groundwater discharge tracer to surface waters*
  (review; provides FINIFLUX scripts). **Earth-Science Reviews**, 238, 104321.
  [doi:10.1016/j.earscirev.2023.104321](https://doi.org/10.1016/j.earscirev.2023.104321)
- Diphofe, K., Diamond, R. & Kotze, F. (2025). *Quantifying baseflow with radon, H and O
  isotopes and field parameters in the urbanized catchment of the Little Jukskei River,
  Johannesburg.* **Hydrology**, 12(8), 203.
  [doi:10.3390/hydrology12080203](https://doi.org/10.3390/hydrology12080203)
- *Overlooked seasonal groundwater nutrient fluxes rival anthropogenic point sources across
  a variable land-use tidal river* (Hawkesbury–Nepean River) (2025). **Limnology and
  Oceanography**. [doi:10.1002/lno.70256](https://doi.org/10.1002/lno.70256)
- *Groundwater contribution to tropical streamflow revealed by radon and stable isotopes*
  (2026). **Environmental Earth Sciences**.
  [doi:10.1007/s12665-026-13068-z](https://doi.org/10.1007/s12665-026-13068-z)
