#!/usr/bin/env python3
"""run_FINIFLUX.py — one-file launcher for the FINIFLUX Python model.

This is the ONLY file you need to execute. It bundles every step:

    1. locate the input spreadsheet (FINIFLUX.xlsx),
    2. add the chosen backend package (PyTorch or TensorFlow) to the import path
       so you do NOT have to ``pip install`` anything beforehand,
    3. read the input file,
    4. run the inverse model (estimate per-reach groundwater inflow I,
       hyporheic-zone depth h, and hyporheic mean residence time t_h) — or just
       the forward model if you prefer,
    5. write the native output files (gw_inflow.dat, depth_hz.dat, rtimes_hz.dat,
       Rn_modeled.csv),
    6. produce the diagnostic plots (radon fit; estimated I/h/t_h in space;
       cumulative groundwater inflow vs distance).

USAGE
-----
Simplest — just run it (uses the CONFIG block below):

    python run_FINIFLUX.py

Override anything from the command line (flags beat the CONFIG defaults):

    python run_FINIFLUX.py --backend tensorflow
    python run_FINIFLUX.py --input path/to/FINIFLUX.xlsx --out my_results
    python run_FINIFLUX.py --mode forward          # forward run only, no fitting
    python run_FINIFLUX.py --adam 500 --lbfgs 150  # more optimisation iterations
    python run_FINIFLUX.py --show                  # pop up the figure window too
    python run_FINIFLUX.py --uncertainty           # also estimate posterior uncertainty
    python run_FINIFLUX.py --no-uncertainty        # turn the uncertainty step off

REQUIREMENTS
------------
Python 3.9+, numpy, openpyxl, matplotlib, and EITHER torch (for --backend pytorch,
the default) OR tensorflow (for --backend tensorflow). Install once, e.g.:

    pip install numpy openpyxl matplotlib torch
    # or, for the TensorFlow backend:
    pip install numpy openpyxl matplotlib tensorflow
"""
from __future__ import annotations

import argparse
import os
import sys

# --------------------------------------------------------------------------- #
# CONFIG — edit these defaults if you don't want to pass command-line flags.
# --------------------------------------------------------------------------- #
CONFIG = {
    "input": "FINIFLUX.xlsx",   # input spreadsheet (relative to this script)
    "backend": "tensorflow",        # "pytorch" or "tensorflow"
    "mode": "invert",            # "invert" (estimate params) or "forward" (run once)
    "out": "results",            # output directory
    "plot": None,                # figure path; None -> <out>/finiflux_plots.png
    "show": True,               # also display the figure window interactively
    # optimisation controls (used in "invert" mode)
    "adam": 300,                 # Adam warm-up steps (both backends)
    "lbfgs": 00,                # L-BFGS iterations (PyTorch only)
    "lr": 0.05,                  # Adam learning rate (TensorFlow uses this directly)
    "iter": 300,                 # Adam iterations (TensorFlow only)
    "smooth": 1e-3,              # smoothness regularisation weight
    "quiet": False,              # suppress per-iteration progress printing
    # hyporheic depth h: if True, COMPUTE h from bedform heights (column N) via the
    # Elliott & Brooks (1997) relation instead of estimating it; the inversion then
    # fits only groundwater inflow I and residence time t_h.
    "bedform_depth": False,
    # uncertainty quantification (invert mode only)
    "uncertainty": True,        # estimate posterior covariance after the fit?
    "unc_method": "gauss_newton",# "gauss_newton" (robust default) or "full" Hessian
    # known radon measurement uncertainty (Bq/m³): drives the ±σ envelope on the
    # radon panel AND is used as the noise model for the parameter uncertainty.
    "rn_sigma_abs": None,        # constant absolute σ for every observation
    "rn_sigma_rel": 0.1,        # relative σ as a fraction of each observation (e.g. 0.1)
    # groundwater-endmember uncertainty (invert mode; needs column U in the xlsx):
    # re-fits the inversion at the low/high endmember percentiles -> a SECOND figure.
    "endmember": True,           # run the endmember-uncertainty analysis?
    "em_p_low": 0.05,            # lower percentile of the N(M, U) endmember
    "em_p_high": 0.95,           # upper percentile of the N(M, U) endmember
}

# Absolute path of the directory containing this script (so it works from anywhere).
HERE = os.path.dirname(os.path.abspath(__file__))


# --------------------------------------------------------------------------- #
# Backend loading
# --------------------------------------------------------------------------- #
def load_backend(backend: str):
    """Import the requested backend package and return its public module.

    We add the package directory to ``sys.path`` on the fly, so neither package
    needs to be pip-installed first.
    """
    backend = backend.lower()
    if backend in ("pytorch", "torch"):
        pkg_dir = os.path.join(HERE, "finiflux_pytorch")
        sys.path.insert(0, pkg_dir)
        try:
            import finiflux_torch as ff
        except ImportError as exc:
            raise SystemExit(
                "Could not import the PyTorch backend. Make sure 'torch' is "
                f"installed (pip install torch).\nOriginal error: {exc}")
        return ff, "pytorch"
    if backend in ("tensorflow", "tf"):
        pkg_dir = os.path.join(HERE, "finiflux_tensorflow")
        sys.path.insert(0, pkg_dir)
        try:
            import finiflux_tf as ff
        except ImportError as exc:
            raise SystemExit(
                "Could not import the TensorFlow backend. Make sure 'tensorflow' "
                f"is installed (pip install tensorflow).\nOriginal error: {exc}")
        return ff, "tensorflow"
    raise SystemExit(f"Unknown backend '{backend}' (use 'pytorch' or 'tensorflow').")


# --------------------------------------------------------------------------- #
# Argument parsing (every CONFIG entry has a matching flag)
# --------------------------------------------------------------------------- #
def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Run the FINIFLUX radon model (forward or inverse).")
    p.add_argument("--input", default=CONFIG["input"], help="input FINIFLUX.xlsx")
    p.add_argument("--backend", default=CONFIG["backend"],
                   choices=["pytorch", "torch", "tensorflow", "tf"],
                   help="autodiff backend to use")
    p.add_argument("--mode", default=CONFIG["mode"],
                   choices=["invert", "forward"],
                   help="'invert' estimates I/h/t_h; 'forward' runs once")
    p.add_argument("--out", default=CONFIG["out"], help="output directory")
    p.add_argument("--plot", default=CONFIG["plot"],
                   help="figure path (default <out>/finiflux_plots.png)")
    p.add_argument("--show", action="store_true", default=CONFIG["show"],
                   help="display the figure interactively as well as saving it")
    p.add_argument("--adam", type=int, default=CONFIG["adam"],
                   help="Adam warm-up steps (PyTorch) / unused label")
    p.add_argument("--lbfgs", type=int, default=CONFIG["lbfgs"],
                   help="L-BFGS iterations (PyTorch only)")
    p.add_argument("--iter", type=int, default=CONFIG["iter"],
                   help="Adam iterations (TensorFlow only)")
    p.add_argument("--lr", type=float, default=CONFIG["lr"],
                   help="Adam learning rate")
    p.add_argument("--smooth", type=float, default=CONFIG["smooth"],
                   help="smoothness regularisation weight")
    p.add_argument("--quiet", action="store_true", default=CONFIG["quiet"],
                   help="suppress per-iteration progress output")
    p.add_argument("--bedform-depth", action=argparse.BooleanOptionalAction,
                   default=CONFIG["bedform_depth"],
                   help="compute hyporheic depth h from bedform heights (column N) via "
                        "Elliott & Brooks (1997) instead of estimating it "
                        "(--bedform-depth / --no-bedform-depth)")
    p.add_argument("--uncertainty", action=argparse.BooleanOptionalAction,
                   default=CONFIG["uncertainty"],
                   help="estimate posterior uncertainty after the fit "
                        "(--uncertainty / --no-uncertainty); invert mode only")
    p.add_argument("--unc-method", default=CONFIG["unc_method"],
                   choices=["gauss_newton", "full"],
                   help="Hessian for the uncertainty: Gauss-Newton or full")
    p.add_argument("--rn-sigma-abs", type=float, default=CONFIG["rn_sigma_abs"],
                   help="known constant radon measurement σ [Bq/m³] "
                        "(±σ envelope on radon panel + noise model)")
    p.add_argument("--rn-sigma-rel", type=float, default=CONFIG["rn_sigma_rel"],
                   help="known relative radon measurement σ (fraction of each obs, "
                        "e.g. 0.1 = 10%%)")
    p.add_argument("--endmember", action=argparse.BooleanOptionalAction,
                   default=CONFIG["endmember"],
                   help="run the GW-endmember uncertainty (re-fit at percentiles; "
                        "needs column U); writes a second figure. Invert mode only")
    p.add_argument("--em-p-low", type=float, default=CONFIG["em_p_low"],
                   help="lower percentile of the N(M,U) endmember (default 0.05)")
    p.add_argument("--em-p-high", type=float, default=CONFIG["em_p_high"],
                   help="upper percentile of the N(M,U) endmember (default 0.95)")
    return p.parse_args(argv)


# --------------------------------------------------------------------------- #
# Uncertainty output writer
# --------------------------------------------------------------------------- #
def write_uncertainty_csv(path, data, unc):
    """Write the per-reach posterior summary (MAP, 1σ, credible interval) to CSV.

    One row per (parameter, reach): the maximum-a-posteriori value, its 1σ
    standard deviation and the lower/upper credible-interval bounds, in physical
    units (I in m³/(m·s), h in m, t_h in seconds — as stored in the model).
    """
    import csv
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Friendly names for the log-space block keys used inside UncertaintyResult.
    nice = {"logI": "I", "logh": "h", "logth": "t_h"}
    pct = int(round(unc.ci_level * 100))
    with open(path, "w", newline="") as fh:
        wr = csv.writer(fh)
        wr.writerow(["parameter", "reach", "x_start_m", "x_end_m",
                     "map", "std", f"ci{pct}_low", f"ci{pct}_high"])
        for name in unc.param_names:
            mp, sd = unc.map_phys[name], unc.std_phys[name]
            lo, hi = unc.ci_low[name], unc.ci_high[name]
            for i in range(unc.n_reaches):
                wr.writerow([nice.get(name, name), i + 1,
                             f"{data.x_node[i]:.6g}", f"{data.x_node[i + 1]:.6g}",
                             f"{mp[i]:.8e}", f"{sd[i]:.8e}",
                             f"{lo[i]:.8e}", f"{hi[i]:.8e}"])


def write_endmember_csv(path, data, result, band):
    """Write the per-reach GW-endmember uncertainty to CSV.

    For each reach: the endmember values used at the two percentiles, the
    best-fit inflow and the inflow at each percentile re-fit, and the resulting
    min/max envelope. Lets you tabulate exactly how the endmember uncertainty maps
    onto the estimated groundwater inflow.
    """
    import csv
    import numpy as np
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rl, rh = band.result_low, band.result_high
    I_lo = np.minimum(rl.inflow, rh.inflow)
    I_hi = np.maximum(rl.inflow, rh.inflow)
    plo, phi = int(round(band.p_low * 100)), int(round(band.p_high * 100))
    with open(path, "w", newline="") as fh:
        wr = csv.writer(fh)
        wr.writerow(["reach", "x_start_m", "x_end_m",
                     f"cgw_p{plo}", f"cgw_p{phi}",
                     "I_bestfit", f"I_fit@p{plo}cgw", f"I_fit@p{phi}cgw",
                     "I_envelope_low", "I_envelope_high"])
        for i in range(data.n_reaches):
            wr.writerow([i + 1, f"{data.x_node[i]:.6g}", f"{data.x_node[i + 1]:.6g}",
                         f"{band.cgw_low[i]:.6g}", f"{band.cgw_high[i]:.6g}",
                         f"{result.inflow[i]:.8e}",
                         f"{rl.inflow[i]:.8e}", f"{rh.inflow[i]:.8e}",
                         f"{I_lo[i]:.8e}", f"{I_hi[i]:.8e}"])


# --------------------------------------------------------------------------- #
# Main driver
# --------------------------------------------------------------------------- #
def main(argv=None):
    args = parse_args(argv)

    # Resolve the input path relative to this script if it isn't absolute.
    input_path = args.input
    if not os.path.isabs(input_path):
        input_path = os.path.join(HERE, input_path)
    if not os.path.isfile(input_path):
        raise SystemExit(f"Input file not found: {input_path}")

    out_dir = args.out if os.path.isabs(args.out) else os.path.join(HERE, args.out)

    # 1) load the chosen backend package (adds it to sys.path; no pip install needed)
    ff, backend = load_backend(args.backend)
    print(f"FINIFLUX | backend = {backend} | mode = {args.mode}")
    print(f"  input : {input_path}")
    print(f"  output: {out_dir}/")

    # 2) read the spreadsheet into the typed InputData structure
    data = ff.read_input(input_path)
    print(f"  parsed {data.n_nodes} nodes / {data.n_reaches} reaches; "
          f"degas model {data.options.degas_model}, RTD {data.options.rtd_model}, "
          f"HZ {'on' if data.options.hz_on else 'off'}")

    # 2b) resolve the known radon measurement uncertainty σ (if any) ---------- #
    # Absolute and/or relative parts combine in quadrature: σ = sqrt(abs² + (rel·obs)²).
    # When given it both shades the ±σ envelope on the radon panel and serves as the
    # noise model for the parameter uncertainty (taken at face value, no rescaling).
    import numpy as np
    rn_sigma = None
    if args.rn_sigma_abs is not None or args.rn_sigma_rel is not None:
        rn_sigma = np.zeros(data.n_nodes)
        if args.rn_sigma_abs is not None:
            rn_sigma = rn_sigma + float(args.rn_sigma_abs)
        if args.rn_sigma_rel is not None:
            rn_sigma = np.sqrt(rn_sigma ** 2 + (float(args.rn_sigma_rel) * data.rn_obs) ** 2)
        print(f"  radon measurement σ : {rn_sigma.min():.3g} .. {rn_sigma.max():.3g} "
              f"Bq/m³ (known; ±σ envelope + noise model)")

    # 2c) hyporheic depth from bedforms (Elliott & Brooks 1997) --------------- #
    # If enabled, h is computed from the bedform heights (column N) and discharge/
    # geometry; the inversion then fits only I and t_h. Auto-skips (with a note) if
    # the hyporheic zone is off or column N holds no bedform heights.
    use_bedform = args.bedform_depth
    if use_bedform and not data.options.hz_on:
        print("  note: --bedform-depth ignored (hyporheic zone is switched off).")
        use_bedform = False
    if use_bedform:
        bh = getattr(data, "bedform_height", None)
        if bh is None or np.all(np.asarray(bh) == 0):
            print("  note: --bedform-depth on but column N has no bedform heights; "
                  "computed h will be 0 (no hyporheic exchange).")
        h_bed = ff.hyporheic_depth_from_bedforms(data)
        print(f"  hyporheic depth h    : COMPUTED from bedforms (Elliott-Brooks), "
              f"{h_bed.min():.3g} .. {h_bed.max():.3g} m (not estimated)")

    # 3) run the model -------------------------------------------------------- #
    cfg = None                       # FitConfig used in invert mode (reused for endmember)
    if args.mode == "forward":
        # single forward evaluation; use the computed bedform depth if enabled.
        result = ff.run_forward(data, hz_depth=(h_bed if use_bedform else None))
    else:
        # inverse estimation. Each backend's FitConfig has slightly different
        # optimiser fields, so build the matching one. use_bedform_depth fixes h.
        if backend == "pytorch":
            cfg = ff.FitConfig(n_adam=args.adam, n_lbfgs=args.lbfgs,
                               smooth_weight=args.smooth,
                               use_bedform_depth=use_bedform)
        else:  # tensorflow
            cfg = ff.FitConfig(n_iter=args.iter, lr=args.lr,
                               smooth_weight=args.smooth,
                               use_bedform_depth=use_bedform)
        result = ff.fit(data, cfg, verbose=not args.quiet)

    # 4) write native output files ------------------------------------------- #
    ff.write_results(out_dir, data, result)
    print("  wrote: gw_inflow.dat, depth_hz.dat, rtimes_hz.dat, Rn_modeled.csv")

    # 4b) optional posterior uncertainty ------------------------------------- #
    # Only meaningful for an inverse run (it linearises the misfit about the
    # fitted optimum). Skipped with a note in forward mode.
    unc = None
    if args.uncertainty:
        if args.mode != "invert":
            print("  note: --uncertainty ignored in forward mode (needs a fit).")
        else:
            print(f"  estimating uncertainty ({args.unc_method} Hessian)...")
            # If a known σ was given, use it at face value (no empirical rescaling);
            # otherwise fall back to the default noise model with calibration on.
            # When h is computed from bedforms it is not a free parameter, so it is
            # excluded from the posterior (only I and t_h carry covariance).
            unc_cfg = ff.UncertaintyConfig(method=args.unc_method,
                                           smooth_weight=args.smooth,
                                           sigma=rn_sigma,
                                           calibrate_sigma=(rn_sigma is None),
                                           estimate_h=not use_bedform)
            unc = ff.estimate_uncertainty(data, result, unc_cfg,
                                          verbose=not args.quiet)
            unc_path = os.path.join(out_dir, "uncertainty.csv")
            write_uncertainty_csv(unc_path, data, unc)
            print(f"  wrote: {unc_path}")

    # 5) diagnostic plots ---------------------------------------------------- #
    plot_path = args.plot or os.path.join(out_dir, "finiflux_plots.png")
    if not os.path.isabs(plot_path):
        plot_path = os.path.join(HERE, plot_path)
    # Only draw the radon ±σ envelope when a *known* measurement σ was supplied;
    # otherwise suppress it so the large default noise model isn't shown as if it
    # were measurement uncertainty.
    if rn_sigma is None and unc is not None:
        unc.sigma = None
    ff.plot_all(data, result, path=plot_path, show=args.show, unc=unc, sigma=rn_sigma)
    print(f"  wrote: {plot_path}")

    # 5b) optional GW-endmember uncertainty -> SECOND figure ----------------- #
    # Re-fits the inversion at the low/high endmember percentiles (needs column U).
    if args.endmember:
        if args.mode != "invert":
            print("  note: --endmember ignored in forward mode (needs a fit).")
        elif getattr(data, "cgw_sd", None) is None:
            print("  note: --endmember skipped (no endmember σ / column U in input).")
        else:
            print(f"  endmember uncertainty: re-fitting at p={args.em_p_low:.2f}"
                  f"/{args.em_p_high:.2f} ...")
            band = ff.endmember_uncertainty(data, cfg, args.em_p_low, args.em_p_high,
                                            verbose=not args.quiet)
            em_plot = os.path.join(out_dir, "finiflux_plots_endmember.png")
            ff.plot_all_endmember(data, result, band, path=em_plot, show=args.show)
            em_csv = os.path.join(out_dir, "endmember_uncertainty.csv")
            write_endmember_csv(em_csv, data, result, band)
            print(f"  wrote: {em_plot}, {em_csv}")

    # 6) quick numeric summary ----------------------------------------------- #
    import numpy as np
    gw_total = float(np.sum(result.inflow * data.dx))  # sum(I_i * dx_i) [m3/s]
    print("\nSummary")
    print(f"  groundwater inflow I : {result.inflow.min():.2e} .. "
          f"{result.inflow.max():.2e} m3/(m s)")
    print(f"  hyporheic depth h    : {result.hz_depth.min():.3f} .. "
          f"{result.hz_depth.max():.3f} m")
    print(f"  residence time t_h   : {result.residence_time.min()/86400:.2f} .. "
          f"{result.residence_time.max()/86400:.2f} days")
    print(f"  total GW inflow      : {gw_total:.4f} m3/s")
    print("done.")


if __name__ == "__main__":
    main()
