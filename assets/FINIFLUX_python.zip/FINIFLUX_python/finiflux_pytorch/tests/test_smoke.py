"""Smoke tests: I/O, forward solve, autograd, and a tiny inversion.

Run with:  pytest finiflux_pytorch/tests
The tests locate FINIFLUX.xlsx at the repository root.
"""
import os
import numpy as np
import pytest

torch = pytest.importorskip("torch")

from finiflux_torch import read_input, run_forward, fit, FitConfig
from finiflux_torch.forward import TorchModel

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
XLSX = os.path.join(ROOT, "FINIFLUX.xlsx")


def test_read_flexible_sizes():
    data = read_input(XLSX)
    assert data.n_nodes == data.n_reaches + 1
    assert data.rn_obs.shape[0] == data.n_nodes
    assert data.dx.shape[0] == data.n_reaches


def test_forward_runs_and_is_finite():
    data = read_input(XLSX)
    res = run_forward(data)
    assert res.rn_model.shape[0] == data.n_nodes
    assert np.all(np.isfinite(res.rn_model))
    # upstream BC enforced at first node
    assert abs(res.rn_model[0] - data.rn_obs[0]) < 1e-3 * max(1.0, data.rn_obs[0])


def test_gradient_flows():
    data = read_input(XLSX)
    model = TorchModel(data)
    I = torch.tensor(data.initial_inflow(), dtype=torch.float64, requires_grad=True)
    h = torch.tensor(data.h0, dtype=torch.float64, requires_grad=True)
    th = torch.tensor(data.initial_residence_time(), dtype=torch.float64, requires_grad=True)
    C = model.solve(I, h, th)
    C.sum().backward()
    assert I.grad is not None and torch.all(torch.isfinite(I.grad))
    assert h.grad is not None and th.grad is not None


def test_twin_recovers_inflow():
    """Generate synthetic data from known I, then check inversion lowers misfit."""
    data = read_input(XLSX)
    truth_I = np.full(data.n_reaches, 5e-6)
    synth = run_forward(data, inflow=truth_I)
    data.rn_obs = synth.rn_model.copy()
    res = fit(data, FitConfig(n_adam=50, n_lbfgs=20, estimate_h=False,
                              estimate_th=False), verbose=False)
    misfit = np.mean((res.rn_model - data.rn_obs) ** 2)
    assert misfit < np.mean((synth.rn_model - data.rn_obs) ** 2) + 1e3
