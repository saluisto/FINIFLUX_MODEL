"""Groundwater-endmember (c_gw) uncertainty by re-fitting at percentile endmembers.

Column M of FINIFLUX.xlsx is the mean GW endmember Rn per reach; column U is its
standard deviation. Treating each reach's endmember as ``N(M_i, U_i)``, we evaluate
the inverse model at the low and high percentiles of that distribution (default
5 % / 95 %) and report the resulting spread in the estimated parameters and the
cumulative groundwater inflow.

Because the endmember is an **input** to the inversion, this is done by
**re-fitting** at each percentile endmember — a higher endmember means the same
observed radon implies *less* groundwater inflow — so the band lands mainly on
``I`` (and the cumulative GW curve), while the re-fitted radon stays close to the
observations in either scenario.

This is a separate add-on: it does not touch ``forward.py`` / ``inverse.py``; it
just calls :func:`inverse.fit` twice on copies of the input with ``c_gw`` replaced.

Usage
-----
    from finiflux_torch import read_input, fit
    from finiflux_torch.endmember import endmember_uncertainty

    data = read_input("FINIFLUX.xlsx")     # must contain column U (endmember σ)
    result = fit(data)
    band = endmember_uncertainty(data, p_low=0.05, p_high=0.95)
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from statistics import NormalDist

import numpy as np

from .forward import ForwardResult
from .inverse import fit, FitConfig


@dataclass
class EndmemberBand:
    """The two percentile re-fits plus the endmember values used (per reach).

    ``result_low`` is the fit at the LOW endmember (tends to give HIGH inflow) and
    ``result_high`` the fit at the HIGH endmember (tends to give LOW inflow); the
    plotting layer derives the per-reach min/max envelope from the pair.
    """
    p_low: float
    p_high: float
    cgw_low: np.ndarray            # [Bq/m3] endmember at p_low  (per reach)
    cgw_high: np.ndarray           # [Bq/m3] endmember at p_high (per reach)
    result_low: ForwardResult      # fit at LOW endmember  (-> tends to HIGH inflow)
    result_high: ForwardResult     # fit at HIGH endmember (-> tends to LOW inflow)


def _percentile_cgw(data, p: float) -> np.ndarray:
    """Reach-wise endmember at probability ``p`` of ``N(c_gw, σ_cgw)``, clipped ≥ 0."""
    z = NormalDist().inv_cdf(p)
    return np.clip(np.asarray(data.cgw, float) + z * np.asarray(data.cgw_sd, float),
                   0.0, None)


def endmember_uncertainty(data, config: FitConfig | None = None,
                          p_low: float = 0.05, p_high: float = 0.95,
                          verbose: bool = True) -> EndmemberBand:
    """Re-fit the inverse model at the low/high GW-endmember percentiles.

    Requires column U (per-reach endmember σ) in the input. ``p_low``/``p_high``
    are the lower/upper probabilities of the normal endmember distribution
    (defaults 0.05 / 0.95). Returns an :class:`EndmemberBand`.
    """
    if getattr(data, "cgw_sd", None) is None:
        raise ValueError(
            "endmember uncertainty requires the per-reach endmember standard "
            "deviation (column U of FINIFLUX.xlsx); none was found in the input.")
    if not (0.0 < p_low < p_high < 1.0):
        raise ValueError(f"need 0 < p_low < p_high < 1 (got {p_low}, {p_high})")

    cgw_low = _percentile_cgw(data, p_low)
    cgw_high = _percentile_cgw(data, p_high)
    if verbose:
        print(f"[endmember] re-fitting at p={p_low:.2f} / p={p_high:.2f}  "
              f"(c_gw {cgw_low.min():.0f}..{cgw_low.max():.0f}  /  "
              f"{cgw_high.min():.0f}..{cgw_high.max():.0f} Bq/m³)")

    # Re-fit on copies of the input with c_gw replaced (everything else untouched).
    res_low = fit(replace(data, cgw=cgw_low), config, verbose=False)
    res_high = fit(replace(data, cgw=cgw_high), config, verbose=False)
    return EndmemberBand(p_low, p_high, cgw_low, cgw_high, res_low, res_high)
