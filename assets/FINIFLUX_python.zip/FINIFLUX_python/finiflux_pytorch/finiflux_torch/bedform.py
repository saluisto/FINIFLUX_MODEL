"""Physically-based hyporheic-zone depth from bedform-driven advective pumping.

Instead of *estimating* the hyporheic-zone depth ``h`` by inversion, compute it
from the stream hydraulics using the Elliott & Brooks (1997, after Fehlman 1985)
relation for the half-amplitude of the dynamic head over a bedform — the quantity
that drives advective pumping:

    h_m = 0.28 · (Ū² / 2g) · ( H / (0.34 d) )^m

    m = 3/8   for H/d ≤ 0.34
    m = 3/2   for H/d > 0.34

with Ū = mean stream velocity = Q/A (A = d·w), H = bedform height [m],
d = mean water depth [m], g = gravity. Q, d, w come straight from FINIFLUX.xlsx
(cols S, K, L); H is supplied per reach in **column N** (re-using the former
HZ-depth column → ``InputData.bedform_height``). The result is used as the
FINIFLUX hyporheic depth ``h``, so the inversion then estimates only groundwater
inflow ``I`` and residence time ``t_h``.

Reference: Elliott, A. H., & Brooks, N. H. (1997), WRR 33(1), 123-136; head
relation after Fehlman, H. M. (1985), MS thesis, Caltech.

Note: ``h_m`` is strictly the dynamic-head half-amplitude (a velocity-head scale,
units of length); here it is taken directly as the hyporheic-exchange depth, as
requested. It is a deterministic function of the (fixed) inputs, so it carries no
posterior uncertainty and no gradients flow to it.
"""
from __future__ import annotations

import numpy as np

G = 9.81  # gravitational acceleration [m/s^2]


def hyporheic_depth_from_bedforms(data, g: float = G) -> np.ndarray:
    """Per-reach hyporheic depth ``h`` [m] from the Elliott & Brooks head relation.

    Uses discharge (col S), depth (col K), width (col L) and the per-reach bedform
    height ``H`` (col N → ``data.bedform_height``). Returns an array of length
    ``n_reaches``. Reaches with no bedform (``H = 0``) get ``h = 0`` (no exchange).
    """
    Q = np.asarray(data.discharge, float)
    d = np.asarray(data.depth, float)
    w = np.asarray(data.width, float)
    if getattr(data, "bedform_height", None) is None:
        raise ValueError(
            "bedform hyporheic depth needs per-reach bedform height H "
            "(column N of FINIFLUX.xlsx → InputData.bedform_height).")
    H = np.asarray(data.bedform_height, float)

    A = d * w
    U = Q / A                                   # mean stream velocity Ū [m/s]
    ratio = H / (0.34 * d)
    m = np.where(H / d <= 0.34, 3.0 / 8.0, 3.0 / 2.0)
    return 0.28 * (U ** 2) / (2.0 * g) * ratio ** m
