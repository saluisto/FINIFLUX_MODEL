"""Hyporheic-zone radon source/sink terms (PyTorch, differentiable).

The hyporheic zone (HZ) is the saturated sediment under/around the channel where
stream water briefly detours, ages, and returns. Because that water is shielded
from the atmosphere, ²²²Rn produced by the sediment accumulates, so returning
water is radon-enriched — a source term in the in-stream balance.

Derivation (consistent with FINIFLUX.m exponential case and pwr.m)
-----------------------------------------------------------------
A parcel of stream water with activity ``C`` enters the HZ, gains radon by
production ``gamma = c_gw * lambda`` and loses it by radioactive decay ``lambda``.
After residing a time ``t`` it returns carrying

    C_hz(t) = (gamma/lambda) * (1 - e^{-lambda t}) + C * e^{-lambda t}
            = c_gw * (1 - e^{-lambda t}) + C * e^{-lambda t}     (since gamma/lambda = c_gw)

Real reaches contain a *distribution* of path lengths, so ``t`` is random with a
residence-time distribution (RTD) ``p(t)``. Averaging ``e^{-lambda t}`` over the
RTD is exactly its Laplace transform evaluated at ``lambda``:

    L(lambda) = E[e^{-lambda t}] = ∫_0^∞ e^{-lambda t} p(t) dt

The volumetric HZ exchange per unit stream length is ``q_hz = h * w * por / t_h``
(zone cross-section h·w·por cycled once per mean residence time t_h). The net
HZ→stream radon flux per unit length is ``q_hz * (mean C_hz - C)`` which, using
the average above, becomes ``q_hz * (1 - L) * (c_gw - C)``. Splitting into a
constant source and a part proportional to C:

    alpha2 = q_hz * (1 - L)        (loss coefficient, multiplies C in the sink term)
    alpha1 = alpha2 * c_gw         (production term)

Sanity check — exponential RTD has ``L = 1/(1 + lambda*t_h)``, giving
``alpha2 = lambda*h*w*por/(1+lambda*t_h)`` and ``alpha1 = c_gw*lambda*…``, i.e.
``gamma*h*w*por/(1+lambda*t_h)``, matching FINIFLUX.m exactly.

All three RTDs reduce ``(alpha1, alpha2)`` to a smooth function of ``h`` and
``t_h``, so gradients flow to both parameters for the inversion.
"""
from __future__ import annotations

import numpy as np
import torch

# Fixed dimensionless quadrature grid for the power-law RTD integral. We integrate
# in the rescaled variable u = t / t_h, so the grid is independent of t_h and can
# be built once. A log-spaced grid spans the heavy tail efficiently; _DU are the
# trapezoid-ish weights (spacing) for a simple Riemann/midpoint sum.
_U = np.logspace(-4, 5, 400)
_DU = np.gradient(_U)


def _laplace_powerlaw(lam_th, exponent: float):
    """Laplace transform of a mean-normalised shifted-Pareto (power-law) RTD.

    We use a shifted Pareto in the rescaled time ``u = t/t_h``:

        p(u) = (p-1) * c^{p-1} / (u + c)^p ,   with c = p - 2  ⇒  mean(u) = 1

    Choosing c = p-2 makes the mean of u exactly 1, so the *dimensional* mean
    residence time is t_h (the parameter we estimate) and the only thing the
    transform depends on is the product ``lam_th = lambda * t_h``.

    Parameters
    ----------
    lam_th : torch.Tensor
        ``lambda * t_h`` per reach (shape [n_reach]).
    exponent : float
        Pareto tail exponent p (> 2 so the mean exists).

    Returns
    -------
    torch.Tensor
        L(lambda) per reach, computed by numerical quadrature over ``_U``.
    """
    p = float(exponent)
    c = p - 2.0
    u = torch.as_tensor(_U, dtype=lam_th.dtype, device=lam_th.device)
    du = torch.as_tensor(_DU, dtype=lam_th.dtype, device=lam_th.device)
    # Shifted-Pareto pdf on the grid.
    pdf = (p - 1.0) * c ** (p - 1.0) / (u + c) ** p
    # Should integrate to ~1; divide by the numeric norm to remove grid error.
    norm = torch.sum(pdf * du)
    # L = E[e^{-lambda t}] = E[e^{-(lambda*t_h) u}]; broadcast reaches × grid.
    expo = torch.exp(-lam_th[:, None] * u[None, :])           # (n_reach, n_grid)
    return torch.sum(expo * (pdf * du)[None, :], dim=1) / norm


def laplace_transform(rtd_model: int, lam, t_h, gamma_alpha: float, pl_exponent: float):
    """RTD Laplace transform ``L(lambda)`` per reach (OPTIONS C17 selects the RTD).

    1 = exponential, 2 = truncated/heavy-tailed power law, 3 = gamma.
    """
    lam_th = lam * t_h                       # dimensionless decay-over-residence
    if rtd_model == 1:                       # exponential: closed form
        return 1.0 / (1.0 + lam_th)
    if rtd_model == 3:                       # gamma (shape a, mean t_h): closed form
        a = float(gamma_alpha)               # OPTIONS C22 shape parameter
        return (1.0 + lam_th / a) ** (-a)
    if rtd_model == 2:                       # power law: numerical quadrature
        return _laplace_powerlaw(lam_th, pl_exponent)
    raise ValueError(f"unknown RTD model {rtd_model}")


def hyporheic_terms(h, t_h, cgw, width, por, lam, rtd_model,
                    gamma_alpha=1.0, pl_exponent=3.0):
    """Return per-reach hyporheic production/loss terms ``(alpha1, alpha2)``.

    See the module docstring for the derivation. ``alpha2`` multiplies ``C`` in
    the in-stream sink term; ``alpha1`` is the constant radon production. Both are
    differentiable w.r.t. ``h`` and ``t_h``.
    """
    q_hz = h * width * por / t_h                                   # HZ exchange per length
    L = laplace_transform(rtd_model, lam, t_h, gamma_alpha, pl_exponent)
    alpha2 = q_hz * (1.0 - L)                                      # loss ∝ C
    alpha1 = alpha2 * cgw                                          # production
    return alpha1, alpha2
