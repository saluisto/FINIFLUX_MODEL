"""FINIFLUX — PyTorch port (differentiable radon mass-balance + autodiff inversion)."""
from .io import read_input, write_results, InputData, Options
from .forward import TorchModel, ForwardResult
from .inverse import fit, run_forward, FitConfig
from .plotting import (
    plot_all, plot_radon, plot_parameters, plot_cumulative_gw,
    plot_uncertainty, cumulative_gw_inflow, cumulative_gw_inflow_ci,
    plot_all_endmember, plot_endmember_uncertainty,
)
# Optional add-on: groundwater-endmember uncertainty by re-fitting at percentiles.
from .endmember import endmember_uncertainty, EndmemberBand
# Physically-based hyporheic depth from bedforms (Elliott & Brooks 1997).
from .bedform import hyporheic_depth_from_bedforms
# Optional add-on: Hessian / posterior-covariance uncertainty (separate module,
# leaves forward.py and inverse.py untouched).
from .uncertainty import (
    estimate_uncertainty, posterior_covariance, identifiability_report,
    UncertaintyConfig, UncertaintyResult,
)

__all__ = [
    "read_input", "write_results", "InputData", "Options",
    "TorchModel", "ForwardResult", "fit", "run_forward", "FitConfig",
    "plot_all", "plot_radon", "plot_parameters", "plot_cumulative_gw",
    "plot_uncertainty", "cumulative_gw_inflow", "cumulative_gw_inflow_ci",
    "plot_all_endmember", "plot_endmember_uncertainty",
    "estimate_uncertainty", "posterior_covariance", "identifiability_report",
    "UncertaintyConfig", "UncertaintyResult",
    "endmember_uncertainty", "EndmemberBand",
    "hyporheic_depth_from_bedforms",
]
