"""Autodiff inverse model (PyTorch).

This module replaces the external BEOPEST optimiser of the original FINIFLUX.
Because the whole forward model (``forward.TorchModel.solve``) is differentiable,
we can compute the gradient of the data-misfit w.r.t. the unknown parameters by
backpropagation and drive a gradient-based optimiser directly.

Estimated, per reach:
    I    groundwater inflow rate        [m³/(m·s)]
    h    hyporheic-zone depth           [m]
    t_h  hyporheic mean residence time  [s]

Design choices
--------------
* **Log-space parameters.** All three quantities are strictly positive, so we
  optimise ``logI, logh, logth`` and exponentiate. This enforces positivity for
  free and gives the optimiser a better-scaled (multiplicative) search space.
* **Normalised misfit.** Residuals are weighted by ``1/max(obs, det_limit)²`` so
  that low- and high-activity nodes contribute comparably and values below the
  detection limit are down-weighted. (This is our own scaling, *not* a copy of
  PEST's Tikhonov machinery.)
* **Optional regularisation.** A light smoothness penalty on the log-parameters
  across adjacent reaches (``smooth_weight``) and an optional prior-anchor toward
  the initial values (``prior_weight``). Both default to small/zero so the data
  drive the fit.
* **Optimiser.** A few Adam steps for a robust warm start, then L-BFGS (quasi-
  Newton with strong-Wolfe line search) for fast final convergence.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

from .forward import TorchModel, ForwardResult


@dataclass
class FitConfig:
    """All knobs for the inversion (sensible defaults; override as needed)."""
    estimate_h: bool = True          # estimate hyporheic depth? (ignored if HZ off)
    estimate_th: bool = True         # estimate residence time?  (ignored if HZ off)
    use_bedform_depth: bool = False  # compute h from bedforms (Elliott-Brooks) instead
                                     # of estimating it -> h fixed, only I & t_h fitted
    n_adam: int = 300                # Adam warm-up iterations
    n_lbfgs: int = 100               # L-BFGS max iterations
    adam_lr: float = 0.05            # Adam learning rate (in log-parameter space)
    smooth_weight: float = 1e-3      # μ_s: penalises Δ(logθ) between adjacent reaches
    prior_weight: float = 0.0        # μ_p: anchors logθ toward initial values (optional)
    # Physical bounds (clamped in log-space each evaluation). Keep parameters in a
    # sane range and prevent the solver wandering into degenerate territory.
    i_bounds: tuple = (1e-10, 1e-2)    # groundwater inflow I  [m³/(m·s)]
    h_bounds: tuple = (1e-3, 1.0)      # hyporheic depth h      [m]   (upper = 1 m)
    th_bounds: tuple = (60.0, 43200.0) # residence time t_h     [s]   (upper = 0.5 day)


def _weights(rn_obs, det_limit):
    """Per-node least-squares weights: inverse-square of the (clipped) observation.

    Dividing the squared residual by ``max(obs, det_limit)²`` turns it into a
    relative error, so a 50 Bq/m³ miss matters as much at a hot node as at a cold
    one, and noise-dominated values below the detection limit cannot dominate the
    objective.
    """
    return 1.0 / np.maximum(rn_obs, det_limit) ** 2


def fit(data, config: FitConfig | None = None, dtype=torch.float64, device="cpu",
        verbose: bool = True) -> ForwardResult:
    """Estimate I, h, t_h by gradient-based minimisation of the radon misfit."""
    cfg = config or FitConfig()
    model = TorchModel(data, dtype=dtype, device=device)
    lam = model.lam

    # --- initial guesses (priors) for the three parameters ---
    I0 = torch.as_tensor(data.initial_inflow(), dtype=dtype, device=device)
    th0 = torch.as_tensor(data.initial_residence_time(), dtype=dtype, device=device)

    # Hyporheic depth: either estimated (legacy) or computed from the Elliott-Brooks
    # bedform head relation. In bedform mode h is deterministic from the inputs, so
    # it is frozen (not trainable) and NOT clamped to h_bounds.
    if cfg.use_bedform_depth:
        from .bedform import hyporheic_depth_from_bedforms
        h0 = torch.as_tensor(hyporheic_depth_from_bedforms(data), dtype=dtype, device=device)
        estimate_h = False
    else:
        h0 = torch.as_tensor(np.asarray(data.h0, float), dtype=dtype, device=device)
        estimate_h = cfg.estimate_h

    # Optimise in log-space. requires_grad is enabled only for parameters we are
    # actually estimating (h and t_h are frozen when hyporheic exchange is off, or
    # when the caller disables them) so the optimiser leaves them at their priors.
    logI = torch.log(I0).clone().requires_grad_(True)
    logh = torch.log(h0).clone().requires_grad_(estimate_h and data.options.hz_on)
    logth = torch.log(th0).clone().requires_grad_(cfg.estimate_th and data.options.hz_on)

    obs = model.rn_obs
    w = torch.as_tensor(_weights(data.rn_obs, data.options.detection_limit),
                        dtype=dtype, device=device)
    # Snapshot of the priors (for the optional prior-anchor regularisation term).
    logI0, logh0, logth0 = logI.detach().clone(), logh.detach().clone(), logth.detach().clone()

    def clamp(t, lo, hi):
        """Clamp a log-parameter to its physical [lo, hi] range (in log units)."""
        return torch.clamp(t, np.log(lo), np.log(hi))

    def closure_loss():
        """Evaluate the scalar objective = weighted misfit + regularisation."""
        # Map log-params back to physical units (with bounds) and run the forward model.
        # Bedform-computed h is used as-is (deterministic, not clamped).
        I = torch.exp(clamp(logI, *cfg.i_bounds))
        h = torch.exp(logh) if cfg.use_bedform_depth else torch.exp(clamp(logh, *cfg.h_bounds))
        th = torch.exp(clamp(logth, *cfg.th_bounds))
        C = model.solve(I, h, th)

        # Data term: normalised sum of squared residuals at the observation nodes.
        misfit = torch.sum(w * (C - obs) ** 2)

        reg = torch.zeros((), dtype=dtype, device=device)
        # Smoothness: penalise large jumps in each log-parameter between reaches.
        if cfg.smooth_weight > 0:
            for p in (logI, logh, logth):
                reg = reg + cfg.smooth_weight * torch.sum(torch.diff(p) ** 2)
        # Prior anchor: pull parameters back toward their initial values (optional).
        if cfg.prior_weight > 0:
            reg = reg + cfg.prior_weight * (
                torch.sum((logI - logI0) ** 2)
                + torch.sum((logh - logh0) ** 2)
                + torch.sum((logth - logth0) ** 2))
        return misfit + reg

    # Collect only the tensors that are actually being optimised.
    params = [logI]
    if estimate_h and data.options.hz_on:
        params.append(logh)
    if cfg.estimate_th and data.options.hz_on:
        params.append(logth)

    # --- Stage 1: Adam warm-up (robust, gets us into a good basin) ---
    adam = torch.optim.Adam(params, lr=cfg.adam_lr)
    for it in range(cfg.n_adam):
        adam.zero_grad()
        loss = closure_loss()
        loss.backward()              # backprop through assembly + linear solve
        adam.step()
        if verbose and it % max(1, cfg.n_adam // 10) == 0:
            print(f"[adam {it:4d}] loss = {loss.item():.6e}")

    # --- Stage 2: L-BFGS refinement (fast quasi-Newton final convergence) ---
    lbfgs = torch.optim.LBFGS(params, max_iter=cfg.n_lbfgs,
                              line_search_fn="strong_wolfe")

    def closure():
        # L-BFGS may evaluate the closure several times per step (line search),
        # so it must re-zero grads, recompute the loss and backprop each call.
        lbfgs.zero_grad()
        loss = closure_loss()
        loss.backward()
        return loss

    lbfgs.step(closure)
    if verbose:
        print(f"[lbfgs end] loss = {closure_loss().item():.6e}")

    # --- final evaluation at the optimum (no grad needed) ---
    with torch.no_grad():
        I = torch.exp(clamp(logI, *cfg.i_bounds))
        h = torch.exp(logh) if cfg.use_bedform_depth else torch.exp(clamp(logh, *cfg.h_bounds))
        th = torch.exp(clamp(logth, *cfg.th_bounds))
        C = model.solve(I, h, th)

    return ForwardResult(
        rn_model=C.cpu().numpy(),
        inflow=I.cpu().numpy(),
        hz_depth=h.cpu().numpy(),
        residence_time=th.cpu().numpy(),
    )


def run_forward(data, inflow=None, hz_depth=None, residence_time=None,
                dtype=torch.float64, device="cpu") -> ForwardResult:
    """Run the forward model once with given (or default/prior) parameters.

    Handy for inspecting the starting point or for generating synthetic data in a
    twin experiment. Parameters left as ``None`` fall back to the input-file /
    default priors.
    """
    model = TorchModel(data, dtype=dtype, device=device)
    I = torch.as_tensor(data.initial_inflow() if inflow is None else inflow,
                        dtype=dtype, device=device)
    h = torch.as_tensor(np.asarray(data.h0 if hz_depth is None else hz_depth, float),
                        dtype=dtype, device=device)
    th = torch.as_tensor(
        data.initial_residence_time() if residence_time is None else residence_time,
        dtype=dtype, device=device)
    with torch.no_grad():
        C = model.solve(I, h, th)
    return ForwardResult(C.cpu().numpy(), I.cpu().numpy(), h.cpu().numpy(), th.cpu().numpy())
