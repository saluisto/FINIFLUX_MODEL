"""Plotting and post-processing for FINIFLUX results.

This module is deliberately framework-agnostic: it only consumes plain NumPy
arrays carried by the :class:`~finiflux_torch.forward.ForwardResult` and the
:class:`~finiflux_torch.io.InputData` objects, so the *exact same* code works for
the PyTorch and TensorFlow ports.

It produces the three diagnostic figure groups requested for FINIFLUX:

1. ``plot_radon``        - simulated vs. observed radon activity in space.
2. ``plot_parameters``   - the inversely estimated, reach-specific parameters in
                           space: groundwater inflow rate ``I``, hyporheic-zone
                           depth ``h`` and hyporheic mean residence time ``t_h``.
3. ``plot_cumulative_gw``- the cumulative groundwater inflow,
                           ``GW(x) = sum_i (I_i * dx_i)`` summed downstream,
                           plotted against distance and compared with the
                           observed discharge increase ``Delta Q`` (manual Eq. 2/3).

``plot_all`` writes/【shows】 all three at once and is what the CLI calls.

Distances are converted to kilometres for readability. Reach (element) quantities
are step-plotted across their reach extent because they are piece-wise constant
between observation nodes; nodal quantities (radon) are plotted at the nodes.
"""
from __future__ import annotations

import numpy as np


# --------------------------------------------------------------------------- #
# Post-processing helpers
# --------------------------------------------------------------------------- #
def cumulative_gw_inflow(data, result):
    """Cumulative groundwater inflow along the stream (manual Eq. 3).

    Per reach the volumetric groundwater inflow is ``q_i = I_i * dx_i`` [m3/s]
    (inflow rate per unit length times reach length). Summing these from the
    upstream end downstream gives the cumulative groundwater contribution at
    every node.

    Returns
    -------
    x_node : np.ndarray
        Node locations [m] (length ``n_nodes``).
    gw_cum : np.ndarray
        Cumulative groundwater inflow [m3/s] at each node (length ``n_nodes``);
        the first node is 0 (nothing has entered yet).
    """
    q_reach = result.inflow * data.dx               # [m3/s] per reach
    gw_cum = np.concatenate([[0.0], np.cumsum(q_reach)])
    return data.x_node, gw_cum


def cumulative_gw_inflow_ci(data, unc):
    """Credible band for the cumulative groundwater inflow (delta method).

    ``GW(x_k) = sum_{i<k} I_i·dx_i`` is linear in the per-reach inflow ``I_i``.
    With ``I_i = exp(logI_i)`` the sensitivity to ``logI_i`` is ``dx_i·I_i``, so
    propagating the posterior covariance of the ``logI`` block gives a normal
    approximation of the cumulative-inflow uncertainty at every node:

        var(GW_k) = c_{≤k}ᵀ · Cov(logI)_{≤k} · c_{≤k},   c_i = dx_i·I_i.

    Returns ``(x_node, gw_cum, lo, hi)`` (the band at the chosen ``unc.ci_level``),
    or ``None`` if no inflow uncertainty is available.
    """
    if unc is None or "logI" not in getattr(unc, "map_phys", {}):
        return None
    n = unc.n_reaches
    j = unc.param_names.index("logI")               # logI covariance sub-block
    cov = unc.cov_log[j * n:(j + 1) * n, j * n:(j + 1) * n]
    I = np.asarray(unc.map_phys["logI"], float)      # per-reach MAP inflow
    c = data.dx * I                                  # dGW/dlogI_i = dx_i·I_i
    gw_cum = np.concatenate([[0.0], np.cumsum(c)])
    # Cumulative quadratic form: var at node k = sum_{a,b ≤ k-1} c_a c_b Cov[a,b].
    M = np.outer(c, c) * cov
    cumM = np.cumsum(np.cumsum(M, axis=0), axis=1)
    var = np.concatenate([[0.0], np.clip(np.diag(cumM), 0.0, None)])
    std = np.sqrt(var)
    from statistics import NormalDist                 # stdlib normal quantile
    z = NormalDist().inv_cdf(0.5 + unc.ci_level / 2.0)
    return data.x_node, gw_cum, np.clip(gw_cum - z * std, 0.0, None), gw_cum + z * std


def discharge_difference(data):
    """Observed discharge increase relative to the first node (manual Eq. 2).

    The spreadsheet stores discharge per *reach* (col S). We map it onto nodes by
    assigning each reach discharge to its downstream node and prepend the first
    reach discharge for the upstream node, then subtract the upstream value so the
    curve starts at 0 and is directly comparable to the cumulative GW inflow.
    """
    q_node = np.concatenate([[data.discharge[0]], data.discharge])  # n_nodes
    return q_node - q_node[0]


def _reach_step(ax, x_node, reach_values, **kwargs):
    """Step-plot a piece-wise-constant per-reach quantity across its extent.

    Each reach value spans [x_node[i], x_node[i+1]]; ``step(where='post')`` draws
    a horizontal segment over that interval. We append the last value once so the
    final reach is drawn to the downstream boundary.
    """
    x_km = x_node / 1000.0
    y = np.concatenate([reach_values, reach_values[-1:]])
    ax.step(x_km, y, where="post", **kwargs)


def _reach_fill(ax, x_node, lo, hi, **kwargs):
    """Shade a piece-wise-constant band [lo, hi] across each reach extent.

    Companion to :func:`_reach_step` for credible-interval bands: each reach value
    spans [x_node[i], x_node[i+1]] so we use ``fill_between(..., step='post')`` and
    repeat the last value to reach the downstream boundary.
    """
    x_km = x_node / 1000.0
    lo2 = np.concatenate([lo, lo[-1:]])
    hi2 = np.concatenate([hi, hi[-1:]])
    ax.fill_between(x_km, lo2, hi2, step="post", **kwargs)


def _set_ylim_from_estimate(ax, est, margin=0.08):
    """Set a panel's y-range from the best-estimate values (with a small margin).

    This keeps the estimate curve readable even when the uncertainty interval is
    far wider than the estimate's own spread; anything outside the range is
    clipped at the axis edge.
    """
    est = np.asarray(est, float)
    finite = est[np.isfinite(est)]
    if finite.size == 0:
        return
    lo, hi = float(finite.min()), float(finite.max())
    span = hi - lo
    if span <= 0:                       # constant parameter: pad around the value
        span = abs(hi) if hi != 0 else 1.0
    pad = margin * span
    ylo = lo - pad
    if lo >= 0:                         # keep positive-only quantities off negatives
        ylo = max(0.0, ylo)
    ax.set_ylim(ylo, hi + pad)


# --------------------------------------------------------------------------- #
# 1) Simulated vs observed radon
# --------------------------------------------------------------------------- #
def plot_radon(ax, data, result, sigma=None, n_sigma=1):
    """Simulated (line) vs observed (markers) radon activity over distance.

    If ``sigma`` (per-node radon measurement uncertainty, [Bq/m³]) is given, a
    shaded ``±n_sigma·σ`` envelope is drawn around the observed points and matching
    error bars are added to the markers. This is the *known measurement
    uncertainty* of the data — the same σ that drives the parameter uncertainty
    analysis (see :func:`~finiflux_torch.uncertainty.posterior_covariance`).
    """
    x_km = data.x_node / 1000.0
    if sigma is not None:
        sigma = np.asarray(sigma, float)
        ax.fill_between(x_km, data.rn_obs - n_sigma * sigma,
                        data.rn_obs + n_sigma * sigma,
                        color="0.5", alpha=0.25, lw=0, zorder=1,
                        label=fr"$\pm{n_sigma}\sigma$ measurement uncertainty")
        ax.errorbar(x_km, data.rn_obs, yerr=n_sigma * sigma, fmt="none",
                    ecolor="0.5", elinewidth=0.8, capsize=2, zorder=2)
    ax.plot(x_km, data.rn_obs, "ko", ms=5, label="observed", zorder=3)
    ax.plot(x_km, result.rn_model, "-", color="crimson", lw=1.8,
            label="simulated", zorder=2)
    ax.set_xlabel("distance along stream [km]")
    ax.set_ylabel(r"$^{222}$Rn activity [Bq m$^{-3}$]")
    ax.set_title("Simulated vs. observed radon")
    ax.legend(frameon=False)
    ax.grid(alpha=0.3)
    # goodness-of-fit annotation (Pearson r and RMSE) for quick QA
    if data.rn_obs.size > 1:
        r = np.corrcoef(data.rn_obs, result.rn_model)[0, 1]
        rmse = float(np.sqrt(np.mean((result.rn_model - data.rn_obs) ** 2)))
        ax.text(0.02, 0.97, f"r = {r:.3f}\nRMSE = {rmse:.1f}",
                transform=ax.transAxes, va="top", ha="left", fontsize=9,
                bbox=dict(boxstyle="round", fc="white", ec="0.7", alpha=0.8))


# --------------------------------------------------------------------------- #
# 2) Estimated reach-specific parameters
# --------------------------------------------------------------------------- #
def plot_parameters(axes, data, result):
    """Estimated groundwater inflow, HZ depth and HZ residence time in space.

    ``axes`` must be a sequence of three matplotlib Axes (one per parameter).
    All three parameters are reach (element) properties, so they are drawn as
    piece-wise-constant steps across each reach.
    """
    ax_i, ax_h, ax_t = axes

    _reach_step(ax_i, data.x_node, result.inflow, color="steelblue", lw=1.8)
    ax_i.set_ylabel(r"$I$ [m$^3$ m$^{-1}$ s$^{-1}$]")
    ax_i.set_title("Estimated groundwater inflow rate")
    ax_i.grid(alpha=0.3)

    _reach_step(ax_h, data.x_node, result.hz_depth, color="seagreen", lw=1.8)
    ax_h.set_ylabel(r"$h_{hz}$ [m]")
    ax_h.set_title("Hyporheic-zone depth")
    ax_h.grid(alpha=0.3)

    # residence time shown in days for readability (stored internally in seconds)
    _reach_step(ax_t, data.x_node, result.residence_time / 86400.0,
                color="darkorange", lw=1.8)
    ax_t.set_ylabel(r"$t_{h}$ [days]")
    ax_t.set_xlabel("distance along stream [km]")
    ax_t.set_title("Estimated hyporheic mean residence time")
    ax_t.grid(alpha=0.3)


# --------------------------------------------------------------------------- #
# 2b) Posterior uncertainty bands on the estimated parameters
# --------------------------------------------------------------------------- #
def plot_uncertainty(axes, data, unc, style="band", color="0.35",
                     alpha=0.22, margin=0.08):
    """Show posterior uncertainty on the estimated-parameter panels.

    Drawn on the *same* three axes as :func:`plot_parameters` (groundwater inflow
    ``I``, HZ depth ``h``, HZ residence time ``t_h``). Two styles are available:

    * ``"band"`` (default) -- a shaded credible-interval ribbon across the reaches;
    * ``"bars"`` -- vertical credible-interval error bars at each reach midpoint,
      sitting on top of the estimate step line.

    In BOTH styles the y-axis range of each panel is set from the *best-estimate*
    values, not from the credible interval, so a wide / poorly-constrained
    interval cannot squash the estimate line flat. Where an interval extends
    beyond the panel it is clipped at the axis edge -- the exact bounds are in
    ``uncertainty.csv`` and the printed summary.

    Only parameters that were actually estimated carry uncertainty; frozen ones
    (e.g. ``h``/``t_h`` when the hyporheic zone is off) are skipped. Residence-time
    values are converted from seconds to days to match the panel.
    """
    ax_i, ax_h, ax_t = axes
    # (block name in UncertaintyResult, target axis, unit scale to match the panel)
    mapping = [("logI", ax_i, 1.0), ("logh", ax_h, 1.0), ("logth", ax_t, 1.0 / 86400.0)]
    pct = int(round(unc.ci_level * 100))
    label = f"{pct}% credible interval"
    # reach midpoints (km): the parameters are piece-wise constant per reach, so
    # the error bar belongs at the centre of each reach.
    xmid_km = 0.5 * (data.x_node[:-1] + data.x_node[1:]) / 1000.0
    for name, ax, scale in mapping:
        if name not in unc.map_phys:            # parameter was not estimated
            continue
        mp = unc.map_phys[name] * scale
        lo = unc.ci_low[name] * scale
        hi = unc.ci_high[name] * scale
        if style == "band":
            _reach_fill(ax, data.x_node, lo, hi, color=color, alpha=alpha,
                        lw=0, zorder=1, label=label)
        else:                                   # "bars" (default)
            yerr = np.vstack([np.clip(mp - lo, 0.0, None),
                              np.clip(hi - mp, 0.0, None)])
            ax.errorbar(xmid_km, mp, yerr=yerr, fmt="none", ecolor=color,
                        elinewidth=1.0, capsize=2, alpha=0.85, zorder=4,
                        label=label)
        # y-range follows the best estimate, not the (possibly huge) interval
        _set_ylim_from_estimate(ax, mp, margin)
        ax.legend(frameon=False, fontsize=8, loc="best")


# --------------------------------------------------------------------------- #
# 3) Cumulative groundwater inflow vs distance
# --------------------------------------------------------------------------- #
def plot_cumulative_gw(ax, data, result, unc=None):
    """Cumulative groundwater inflow ``sum(I_i * dx_i)`` against distance.

    Also overlays the observed discharge increase ``Delta Q`` (col S) so the
    radon-derived groundwater contribution can be sanity-checked against the
    measured water balance (manual "Evaluating Model Outputs for Plausibility").
    If ``unc`` is given, a credible band propagated from the ``logI`` posterior
    covariance is shaded around the cumulative curve (see
    :func:`cumulative_gw_inflow_ci`).
    """
    x_node, gw_cum = cumulative_gw_inflow(data, result)
    x_km = x_node / 1000.0

    band = cumulative_gw_inflow_ci(data, unc)
    if band is not None:
        _, _, lo, hi = band
        pct = int(round(unc.ci_level * 100))
        ax.fill_between(x_km, lo, hi, color="navy", alpha=0.18, lw=0, zorder=1,
                        label=f"{pct}% credible interval")

    ax.plot(x_km, gw_cum, "-o", color="navy", ms=3, lw=1.8, zorder=3,
            label=r"cumulative GW inflow  $\sum I_i\,\Delta x_i$")
    ax.plot(x_km, discharge_difference(data), "--", color="grey", lw=1.5,
            label=r"observed $\Delta Q$ (discharge increase)")
    ax.set_xlabel("distance along stream [km]")
    ax.set_ylabel(r"cumulative flux [m$^3$ s$^{-1}$]")
    ax.set_title("Cumulative groundwater inflow vs. distance")
    ax.legend(frameon=False, loc="upper left")
    ax.grid(alpha=0.3)
    # y-range follows the best-fit cumulative curve (and the observed ΔQ line),
    # not the credible band, so a wide band cannot squash the curve flat.
    if band is not None:
        _set_ylim_from_estimate(ax, np.concatenate([gw_cum, discharge_difference(data)]))
    # report totals (manual Eq. 2): total GW vs total discharge gain
    total_gw = float(gw_cum[-1])
    total_dq = float(discharge_difference(data)[-1])
    ax.text(0.98, 0.03,
            f"$\\Sigma$GW = {total_gw:.3f} m³/s\n$\\Delta Q$ = {total_dq:.3f} m³/s",
            transform=ax.transAxes, va="bottom", ha="right", fontsize=9,
            bbox=dict(boxstyle="round", fc="white", ec="0.7", alpha=0.8))


# --------------------------------------------------------------------------- #
# Combined figure
# --------------------------------------------------------------------------- #
def plot_all(data, result, path: str | None = None, show: bool = False, unc=None,
             sigma=None):
    """Build all three diagnostic plot groups in a single figure.

    Layout (5 stacked panels sharing the distance axis):
        1. simulated vs observed radon
        2. estimated groundwater inflow rate     I(x)
        3. estimated hyporheic-zone depth        h(x)
        4. estimated hyporheic residence time    t_h(x)
        5. cumulative groundwater inflow         sum(I*dx)(x)

    Parameters
    ----------
    path : str or None
        If given, the figure is saved here (PNG). A non-interactive backend is
        selected automatically so this works on headless machines.
    show : bool
        If True (and ``path`` is None), call ``plt.show()``.
    unc : UncertaintyResult or None
        If given, posterior credible-interval bands are overlaid on the three
        parameter panels (see :func:`plot_uncertainty`).
    sigma : array-like or None
        Per-node radon measurement uncertainty for the ±σ envelope on the radon
        panel. If None it falls back to ``unc.sigma`` (the σ used in the analysis).
    """
    import matplotlib
    if path is not None and not show:
        matplotlib.use("Agg")          # headless-safe when only saving
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(5, 1, figsize=(10, 14), sharex=True,
                             constrained_layout=True)
    rn_sigma = sigma if sigma is not None else getattr(unc, "sigma", None)
    plot_radon(axes[0], data, result, sigma=rn_sigma)
    plot_parameters(axes[1:4], data, result)
    if unc is not None:
        plot_uncertainty(axes[1:4], data, unc)
    plot_cumulative_gw(axes[4], data, result, unc=unc)
    fig.suptitle("FINIFLUX results", fontsize=14, fontweight="bold")

    if path is not None:
        fig.savefig(path, dpi=150)
    if show:
        plt.show()
    return fig


# --------------------------------------------------------------------------- #
# Groundwater-endmember uncertainty (separate figure)
# --------------------------------------------------------------------------- #
def _endmember_envelopes(data, band):
    """Per-reach (and per-node) min/max envelopes from the two percentile re-fits.

    Returns a dict with ``inflow``, ``hz_depth``, ``residence_time`` (per reach),
    ``rn`` (per node) and ``cum`` (cumulative GW, per node), each a ``(lo, hi)``
    pair. min/max is used so the direction of the endmember→parameter mapping does
    not matter.
    """
    rl, rh = band.result_low, band.result_high
    mm = lambda a, b: (np.minimum(a, b), np.maximum(a, b))
    env = {
        "inflow": mm(rl.inflow, rh.inflow),
        "hz_depth": mm(rl.hz_depth, rh.hz_depth),
        "residence_time": mm(rl.residence_time, rh.residence_time),
        "rn": mm(rl.rn_model, rh.rn_model),
    }
    cum_l = np.concatenate([[0.0], np.cumsum(rl.inflow * data.dx)])
    cum_h = np.concatenate([[0.0], np.cumsum(rh.inflow * data.dx)])
    env["cum"] = mm(cum_l, cum_h)
    return env


def plot_endmember_uncertainty(axes, data, band, result, color="firebrick", alpha=0.22):
    """Shade the GW-endmember band on the I/h/t_h panels (re-fit at p_low/p_high).

    Drawn on the same three axes as :func:`plot_parameters`; the y-range follows
    the best-estimate ``result`` (not the band), consistent with the other panels.
    """
    env = _endmember_envelopes(data, band)
    label = (f"{int(round(band.p_low * 100))}–{int(round(band.p_high * 100))}% "
             f"endmember band")
    spec = [("inflow", axes[0], 1.0, result.inflow),
            ("hz_depth", axes[1], 1.0, result.hz_depth),
            ("residence_time", axes[2], 1.0 / 86400.0, result.residence_time)]
    for key, ax, scale, est in spec:
        lo, hi = env[key]
        _reach_fill(ax, data.x_node, lo * scale, hi * scale, color=color,
                    alpha=alpha, lw=0, zorder=1, label=label)
        _set_ylim_from_estimate(ax, est * scale)
        ax.legend(frameon=False, fontsize=8, loc="best")


def plot_all_endmember(data, result, band, path: str | None = None,
                       show: bool = False, color="firebrick"):
    """Second diagnostic figure: the five panels of :func:`plot_all` but with the
    **groundwater-endmember** uncertainty band (from re-fitting at the percentile
    endmembers) instead of the posterior/measurement band.

    The radon-panel band is narrow by construction (each re-fit re-matches the
    observations); the informative bands are on ``I``, ``t_h`` and the cumulative
    GW inflow.
    """
    import matplotlib
    if path is not None and not show:
        matplotlib.use("Agg")          # headless-safe when only saving
    import matplotlib.pyplot as plt

    env = _endmember_envelopes(data, band)
    x_km = data.x_node / 1000.0
    pct = (f"{int(round(band.p_low * 100))}–{int(round(band.p_high * 100))}% "
           f"endmember band")

    fig, axes = plt.subplots(5, 1, figsize=(10, 14), sharex=True,
                             constrained_layout=True)
    # 1) radon (central fit) + endmember band
    plot_radon(axes[0], data, result)
    rn_lo, rn_hi = env["rn"]
    axes[0].fill_between(x_km, rn_lo, rn_hi, color=color, alpha=0.22, lw=0,
                         zorder=1, label=pct)
    axes[0].legend(frameon=False)
    # 2-4) estimated parameters + endmember bands
    plot_parameters(axes[1:4], data, result)
    plot_endmember_uncertainty(axes[1:4], data, band, result, color=color)
    # 5) cumulative GW (central) + endmember band, range from the best-fit curve
    plot_cumulative_gw(axes[4], data, result)
    cum_lo, cum_hi = env["cum"]
    axes[4].fill_between(x_km, cum_lo, cum_hi, color=color, alpha=0.22, lw=0,
                         zorder=1, label=pct)
    _set_ylim_from_estimate(
        axes[4], np.concatenate([cumulative_gw_inflow(data, result)[1],
                                 discharge_difference(data)]))
    axes[4].legend(frameon=False, loc="upper left")

    fig.suptitle("FINIFLUX results — groundwater endmember uncertainty",
                 fontsize=14, fontweight="bold")
    if path is not None:
        fig.savefig(path, dpi=150)
    if show:
        plt.show()
    return fig


# Backwards-compatible alias used by earlier code/tests.
def plot_results(data, result, path: str | None = None):
    return plot_all(data, result, path=path, show=(path is None))
