"""Differentiable steady-state radon forward model (PyTorch).

This is the heart of the port: it numerically solves the steady-state ²²²Rn mass
balance along a 1-D stream, exactly as the original ``FINIFLUX.m`` does, but
written entirely in differentiable PyTorch operations so that gradients of the
modelled radon w.r.t. the unknown parameters (groundwater inflow ``I``,
hyporheic depth ``h``, residence time ``t_h``) are available by autograd. Those
gradients are what the inverse model (``inverse.py``) uses instead of PEST.

Physics (steady state, one reach)
---------------------------------
The stream carries radon downstream by advection (discharge ``Q``) while sources
add radon and sinks remove it. Writing ``C(x)`` for the radon activity:

    Q dC/dx = [ I·c_gw + α1 + (Qin/L)·cin ]                (sources, "P")
            - [ I + α2 + k·w + λ·d·w + Qin/L ] · C         (sinks ∝ C, "S")

where, per reach:
    I      groundwater inflow rate           [m³/(m·s)]   (estimated)
    c_gw   radon endmember of groundwater    [Bq/m³]      (col M)
    α1,α2  hyporheic production / loss        (see hyporheic.py; depend on h, t_h)
    k      gas-evasion (degassing) coeff.     [m/s]        (see degassing.py)
    w,d    reach width, depth                 [m]          (cols L, K)
    λ      ²²²Rn decay constant              [1/s]        (≈ 0.18/86400)
    Qin    tributary / surface inflow         [m³/s]       (col P)
    L (=Rl) tributary inflow length           [m]          (col Q)
    cin    tributary radon activity           [Bq/m³]      (col R)

Numerics
--------
The reach is discretised with linear (P1) finite elements; each reach contributes
a 2×2 element matrix (a consistent reaction term + a Galerkin advection term) and
a 2-entry load vector. A Petrov-Galerkin "upstream weighting" correction
(controlled by ``beta`` = OPTIONS C24) is added to suppress numerical
oscillations on advection-dominated reaches. The element contributions are
scattered into a global (N×N) matrix ``A`` and load vector ``b`` (N = number of
nodes), the upstream Dirichlet boundary condition is imposed by the penalty
trick, and the linear system ``A C = b`` is solved. Every step is a torch op, so
``C`` is differentiable w.r.t. ``I``, ``h`` and ``t_h``.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

from .degassing import gas_coefficient
from .hyporheic import hyporheic_terms

# Petrov-Galerkin scaling constant, fixed at 0.75 in FINIFLUX.m. The actual
# amount of upwinding is this times ``beta`` (the user-set OPTIONS C24 weight).
_ALP = 0.75


@dataclass
class ForwardResult:
    """Container for a single model evaluation (plain NumPy, framework-neutral)."""
    rn_model: np.ndarray        # modelled radon at the nodes        [Bq/m³]
    inflow: np.ndarray          # groundwater inflow rate I per reach [m³/(m·s)]
    hz_depth: np.ndarray        # hyporheic-zone depth h per reach    [m]
    residence_time: np.ndarray  # hyporheic mean residence time t_h   [s]


class TorchModel:
    """Pre-builds the constant reach data as tensors; ``solve`` runs the FE model.

    Everything that does *not* depend on the estimated parameters (geometry,
    discharge, connectivity, the upstream BC value) is converted to tensors once
    in ``__init__`` so the per-iteration ``solve`` call stays cheap and the
    optimiser can hammer it thousands of times.
    """

    def __init__(self, data, dtype=torch.float64, device="cpu"):
        self.data = data
        self.opt = data.options          # parsed OPTIONS block (degas model, RTD, beta, …)
        self.dtype = dtype               # float64 by default: the FE solve is ill-conditioned
        self.device = device

        # Small helper: turn any array-like into a tensor of the chosen dtype/device.
        t = lambda a: torch.as_tensor(np.asarray(a, float), dtype=dtype, device=device)

        # --- constant per-reach geometry & forcing (one value per reach) ---
        self.dx = t(data.dx)             # reach length            [m]   (col J)
        self.depth = t(data.depth)       # reach depth             [m]   (col K)
        self.width = t(data.width)       # reach width             [m]   (col L)
        self.cgw = t(data.cgw)           # GW radon endmember      [Bq/m³] (col M)
        self.por = t(data.por)           # streambed porosity      [-]   (col O)
        self.qin = t(data.qin)           # tributary discharge     [m³/s] (col P)
        self.cin = t(data.cin)           # tributary radon         [Bq/m³] (col R)
        self.Q = t(data.discharge)       # reach discharge Q       [m³/s] (col S)
        self.user_k = t(data.user_k)     # user degassing k        [m/s]  (col T)

        # Tributary inflow length L appears as Qin/L. Where there is no tributary
        # the length is 0; FINIFLUX.m replaces those zeros with 1 so the division
        # is harmless (Qin is 0 there anyway). Mirror that exactly.
        rl = np.where(data.inflow_len == 0, 1.0, data.inflow_len)
        self.rl = t(rl)

        self.lam = float(self.opt.lambda_rn)   # decay constant λ  [1/s]
        self.n = data.n_reaches                # number of reaches (elements)
        self.rn_obs = t(data.rn_obs)           # measured radon at nodes (col G)

        # --- assembly index maps (constant; depend only on the mesh size) ---
        # Reach i couples its two nodes i and i+1, giving four matrix entries
        # (i,i), (i,i+1), (i+1,i), (i+1,i+1). Pre-compute the row/col index lists
        # so ``solve`` can scatter all reaches at once with index_put_.
        i = np.arange(self.n)
        self.rows = torch.as_tensor(
            np.concatenate([i, i, i + 1, i + 1]), dtype=torch.long, device=device)
        self.cols = torch.as_tensor(
            np.concatenate([i, i + 1, i, i + 1]), dtype=torch.long, device=device)
        # Load-vector entries land on nodes i and i+1.
        self.brows = torch.as_tensor(
            np.concatenate([i, i + 1]), dtype=torch.long, device=device)

    # ------------------------------------------------------------------ #
    def solve(self, inflow, hz_depth, residence_time):
        """Assemble and solve the FE system for the nodal radon profile.

        Parameters
        ----------
        inflow, hz_depth, residence_time : torch.Tensor
            Per-reach parameters ``I`` [m³/(m·s)], ``h`` [m] and ``t_h`` [s].
            Pass tensors with ``requires_grad=True`` to get gradients.

        Returns
        -------
        torch.Tensor
            Modelled radon activity at every node (length ``n_reaches + 1``).
        """
        d, w, Q, dx = self.depth, self.width, self.Q, self.dx
        lam, beta = self.lam, float(self.opt.beta)

        # 1) Degassing coefficient k [m/s] per reach (empirical or user-supplied).
        k = gas_coefficient(self.opt.degas_model, Q, d, w, self.user_k)

        # 2) Hyporheic source (α1) and loss (α2) terms. Zero when HZ is switched
        #    off (OPTIONS C13 = 0); otherwise they depend on h and t_h via the RTD.
        if self.opt.hz_on:
            a1, a2 = hyporheic_terms(
                hz_depth, residence_time, self.cgw, w, self.por, lam,
                self.opt.rtd_model, self.opt.gamma_alpha, self.opt.pl_exponent)
        else:
            a1 = torch.zeros_like(dx)
            a2 = torch.zeros_like(dx)

        # 3) Lump the reaction (sink) coefficient S and the source load P per reach.
        #    S multiplies C in the PDE; P is the constant source. (See module docstring.)
        trib = self.qin / self.rl
        S = inflow + a2 + k * w + lam * d * w + trib            # sinks ∝ C
        P = inflow * self.cgw + a1 + trib * self.cin            # sources

        # 4) Element matrix entries. For a linear element of length dx the
        #    consistent reaction matrix is S*dx*[[1/3,1/6],[1/6,1/3]] and the
        #    Galerkin advection matrix is Q*[[-1/2,1/2],[-1/2,1/2]]; summing them
        #    gives the four entries below (identical algebra to FINIFLUX.m).
        e00 = S * dx / 3.0 - Q / 2.0
        e01 = S * dx / 6.0 + Q / 2.0
        e10 = S * dx / 6.0 - Q / 2.0
        e11 = S * dx / 3.0 + Q / 2.0

        # 5) Petrov-Galerkin upstream correction (adds artificial upwind diffusion
        #    scaled by beta*ALP). Stabilises advection-dominated reaches; with
        #    beta = 0 these vanish and the scheme reduces to plain Galerkin.
        ba = beta * _ALP / 3.0
        c00 = ba * (2.0 * Q - S * dx)
        c01 = -ba * (2.0 * Q + S * dx)
        c10 = -ba * (2.0 * Q - S * dx)
        c11 = ba * (2.0 * Q + S * dx)

        # Flatten the four (corrected) entries of every reach into one vector,
        # ordered to match self.rows / self.cols above.
        a_vals = torch.cat([e00 + c00, e01 + c01, e10 + c10, e11 + c11])

        # 6) Load vector: consistent source S*dx*[1/2,1/2] plus its upstream
        #    correction. v_half is split equally to both nodes; cv is the upwind part.
        v_half = P * dx / 2.0
        cv = (2.0 * beta / 3.0) * P * dx
        b_vals = torch.cat([v_half - cv, v_half + cv])

        # 7) Scatter the element contributions into the global system (A, b).
        #    accumulate=True sums overlapping node contributions from adjacent reaches.
        N = self.n + 1
        A = torch.zeros((N, N), dtype=self.dtype, device=self.device)
        A.index_put_((self.rows, self.cols), a_vals, accumulate=True)
        b = torch.zeros(N, dtype=self.dtype, device=self.device)
        b.index_put_((self.brows,), b_vals, accumulate=True)

        # 8) Upstream Dirichlet boundary condition: fix C at node 0 to the first
        #    measured radon value. The penalty trick multiplies the (0,0) diagonal
        #    by 1e6 and sets b[0] = penalty * C_bc, so the solve returns C[0] ≈ C_bc
        #    without destroying differentiability (no in-place row assignment).
        c_bc = self.rn_obs[0]
        pen = A[0, 0] * 1.0e6
        e0 = torch.zeros(N, dtype=self.dtype, device=self.device)
        e0[0] = 1.0
        # Replace only the (0,0) entry: add (pen - A00) on the diagonal via outer(e0,e0).
        A = A + torch.outer(e0, e0) * (pen - A[0, 0])
        # Replace only b[0] with pen*c_bc (keep all other entries unchanged).
        b = b * (1.0 - e0) + e0 * (pen * c_bc)

        # 9) Solve the (dense) linear system. Dense is fine for typical N (10²–10³)
        #    and autograd differentiates cleanly through torch.linalg.solve.
        C = torch.linalg.solve(A, b)
        return C
