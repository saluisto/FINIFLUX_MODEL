"""Smoke tests for the TensorFlow port (mirror of the PyTorch tests).

Run with:  pytest finiflux_tensorflow/tests
"""
import os
import numpy as np
import pytest

tf = pytest.importorskip("tensorflow")

from finiflux_tf import read_input, run_forward, fit, FitConfig
from finiflux_tf.forward import TFModel

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
XLSX = os.path.join(ROOT, "FINIFLUX.xlsx")


def test_read_flexible_sizes():
    data = read_input(XLSX)
    assert data.n_nodes == data.n_reaches + 1
    assert data.rn_obs.shape[0] == data.n_nodes


def test_forward_runs_and_is_finite():
    data = read_input(XLSX)
    res = run_forward(data)
    assert res.rn_model.shape[0] == data.n_nodes
    assert np.all(np.isfinite(res.rn_model))
    assert abs(res.rn_model[0] - data.rn_obs[0]) < 1e-3 * max(1.0, data.rn_obs[0])


def test_gradient_flows():
    data = read_input(XLSX)
    model = TFModel(data)
    I = tf.Variable(data.initial_inflow(), dtype=tf.float64)
    h = tf.Variable(data.h0, dtype=tf.float64)
    th = tf.Variable(data.initial_residence_time(), dtype=tf.float64)
    with tf.GradientTape() as tape:
        C = model.solve(I, h, th)
        s = tf.reduce_sum(C)
    g = tape.gradient(s, [I, h, th])
    assert all(gi is not None and np.all(np.isfinite(gi.numpy())) for gi in g)


def test_twin_recovers_inflow():
    data = read_input(XLSX)
    truth_I = np.full(data.n_reaches, 5e-6)
    synth = run_forward(data, inflow=truth_I)
    data.rn_obs = synth.rn_model.copy()
    res = fit(data, FitConfig(n_iter=150, estimate_h=False, estimate_th=False),
              verbose=False)
    misfit = np.mean((res.rn_model - data.rn_obs) ** 2)
    assert np.isfinite(misfit)
