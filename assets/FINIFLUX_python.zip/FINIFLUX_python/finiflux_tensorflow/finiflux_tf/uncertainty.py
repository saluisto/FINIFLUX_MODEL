"""Posterior-covariance / Hessian-based uncertainty for the autodiff inverse model.

TensorFlow mirror of ``finiflux_torch/uncertainty.py``: identical statistics and
API, only the autodiff backend differs (``tf.GradientTape`` instead of
``torch.autograd.functional``). It is a **separate, optional add-on** and does not
change ``forward.py`` or ``inverse.py``. It takes a fitted parameter set (the
optimum from ``inverse.fit``) and quantifies how well-constrained those parameters
are, reusing the same differentiable forward model (``forward.TFModel.solve``).

The statistics (Laplace / Gauss-Newton)
---------------------------------------
We treat the calibrated parameters ``θ`` (in **log space**, as in ``inverse.py``)
as the maximum-a-posteriori (MAP) point of a Gaussian-noise inverse problem and
form the **Laplace approximation** of the posterior:

    θ | data  ~  N( θ̂ ,  Σ )    with    Σ = H(θ̂)⁻¹

where ``H`` is the Hessian of the negative log-posterior at the optimum,

    nlp(θ) = ½ Σ_j ((C_j(θ) − obs_j) / σ_j)²        (Gaussian data misfit)
           + ½ λ_s Σ (Δθ)²                          (smoothness prior, optional)
           + ½ λ_p Σ (θ − θ₀)²                      (prior anchor, optional).

``σ_j`` is the observation standard deviation (default
``σ_j = max(obs_j, detection_limit)`` — the same inverse-square weighting used for
the misfit in ``inverse.py``, now read as a noise model). ``λ_s, λ_p`` are the
*precisions* (inverse variances) of the optional Gaussian priors and play exactly
the role of the regularisation weights in ``inverse.py``.

Two ways to get ``H``:

* **Full Hessian** — two nested ``tf.GradientTape`` passes over ``nlp`` (gradient,
  then its Jacobian). Exact second derivatives, including the model curvature
  ``∂²C/∂θ²``.
* **Gauss–Newton** — ``H ≈ Jᵀ Σ⁻¹ J + (prior Hessian)`` with ``J = ∂C/∂θ`` from
  ``tape.jacobian``. Drops ``∂²C/∂θ²``, so it is cheaper and guaranteed positive
  semi-definite (the robust default near a good optimum).

Covariance is computed in log-space; physical-parameter covariance follows from
the delta method ``Cov(p) ≈ diag(p) · Cov(logθ) · diag(p)`` since ``p = exp(θ)``.

Identifiability
---------------
Radon-only inversion of three per-reach parameters (I, h, t_h) against one
observation per node is **equifinal**: some parameter *combinations* are barely
constrained. The eigen-decomposition of ``H`` exposes which — see
:func:`identifiability_report`.

Usage
-----
    from finiflux_tf import read_input, fit
    from finiflux_tf.uncertainty import estimate_uncertainty

    data = read_input("FINIFLUX.xlsx")
    result = fit(data)                          # MAP estimate (forward/inverse unchanged)
    unc = estimate_uncertainty(data, result)    # Laplace posterior on top of it
    print(unc.summary())
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import tensorflow as tf

from .forward import TFModel


# ---------------------------------------------------------------------------- #
# Configuration
# ---------------------------------------------------------------------------- #
@dataclass
class UncertaintyConfig:
    """Knobs for the posterior-covariance computation.

    Defaults mirror the assumptions baked into ``inverse.FitConfig`` so the
    uncertainty is consistent with how the fit was actually obtained.
    """
    method: str = "gauss_newton"      # "gauss_newton" (default, robust) or "full"
    estimate_h: bool = True           # include log h in θ (ignored if HZ off)
    estimate_th: bool = True          # include log t_h in θ (ignored if HZ off)

    # Observation noise model. If ``sigma`` is None we use σ_j = max(obs, det_lim),
    # i.e. the same scaling as the inverse misfit weights w_j = 1/σ_j². Pass an
    # array of real measurement uncertainties here for a calibrated UQ.
    sigma: Optional[np.ndarray] = None

    # Gaussian-prior precisions (inverse variances) on the log-parameters. Set to
    # the same values used during the fit for a self-consistent posterior; leave at
    # 0 for a pure likelihood (data-only) covariance.
    smooth_weight: float = 0.0        # λ_s on Δ(logθ) between adjacent reaches
    prior_weight: float = 0.0         # λ_p on (logθ − logθ₀)

    # Empirical noise rescaling: multiply Σ by s² = misfit/(N_obs − N_par). Use
    # this when σ is only known up to an overall scale (the usual field situation).
    calibrate_sigma: bool = True

    ci_level: float = 0.95            # central credible-interval level for the report
    jitter: float = 1e-10             # added to the Hessian diagonal before inverting


@dataclass
class UncertaintyResult:
    """Posterior summary. All blocks are ordered [logI, (logh), (logth)] per reach."""
    param_names: list                 # e.g. ["logI", "logh", "logth"] that are active
    n_reaches: int
    theta: np.ndarray                 # MAP point in log space (concatenated blocks)
    cov_log: np.ndarray               # posterior covariance in log space  (n×n)
    hessian: np.ndarray               # negative-log-posterior Hessian      (n×n)
    sigma_scale: float                # applied s² calibration factor (1.0 if off)
    ci_level: float = 0.95            # credible-interval level the CIs were built at
    sigma: Optional[np.ndarray] = None  # per-node radon obs σ used in the analysis

    # Per-parameter physical-space summaries, split back into per-reach blocks.
    map_phys: dict = field(default_factory=dict)   # name -> MAP value   (per reach)
    std_phys: dict = field(default_factory=dict)   # name -> 1σ std-dev  (per reach)
    ci_low: dict = field(default_factory=dict)     # name -> CI lower    (per reach)
    ci_high: dict = field(default_factory=dict)    # name -> CI upper    (per reach)

    def correlation(self) -> np.ndarray:
        """Posterior correlation matrix (log space)."""
        d = np.sqrt(np.clip(np.diag(self.cov_log), 1e-300, None))
        return self.cov_log / np.outer(d, d)

    def summary(self) -> str:
        """Compact text report: per-parameter MAP ± std and credible intervals."""
        lines = [
            f"Posterior summary  (Laplace approx., σ-scale = {self.sigma_scale:.3g})",
            f"  parameters: {', '.join(self.param_names)}  ×  {self.n_reaches} reaches",
        ]
        for name in self.param_names:
            phys = self.map_phys[name]
            std = self.std_phys[name]
            # report the median relative 1σ uncertainty across reaches
            rel = np.median(std / np.maximum(np.abs(phys), 1e-300))
            lines.append(
                f"  {name:>5s}: median value={np.median(phys):.3e}, "
                f"median 1σ={np.median(std):.3e}  ({100*rel:.0f}% rel.)")
        return "\n".join(lines)


# ---------------------------------------------------------------------------- #
# Core
# ---------------------------------------------------------------------------- #
def _resolve_sigma(data, cfg: UncertaintyConfig):
    """Per-node radon observation σ used as the Gaussian noise model.

    Default ``σ_j = max(obs_j, detection_limit)`` (the inverse-square weighting of
    ``inverse.py`` read as a noise model). A user-supplied ``cfg.sigma`` overrides
    it: a scalar is broadcast to all nodes, an array is used as-is. This is the
    "known measurement uncertainty" of the radon data.
    """
    n = len(np.asarray(data.rn_obs))
    if cfg.sigma is None:
        return np.maximum(np.asarray(data.rn_obs, float), data.options.detection_limit)
    s = np.asarray(cfg.sigma, float)
    return np.full(n, float(s)) if s.ndim == 0 else s


def _active_blocks(data, cfg: UncertaintyConfig):
    """Which parameter blocks are estimated, mirroring inverse.fit's logic."""
    names = ["logI"]
    if cfg.estimate_h and data.options.hz_on:
        names.append("logh")
    if cfg.estimate_th and data.options.hz_on:
        names.append("logth")
    return names


def _theta_at_optimum(data, result, names, dtype):
    """Pack the fitted (physical) parameters from a ForwardResult into a log-space
    θ vector, ordered to match ``names`` (one block of length n_reaches each)."""
    lookup = {
        "logI": np.log(np.asarray(result.inflow, float)),
        "logh": np.log(np.asarray(result.hz_depth, float)),
        "logth": np.log(np.asarray(result.residence_time, float)),
    }
    theta = np.concatenate([lookup[name] for name in names])
    return tf.constant(theta, dtype=dtype)


def _make_nlp(model: TFModel, data, result, cfg, names, dtype):
    """Build the negative-log-posterior ``nlp(θ)`` and a model-output map ``C(θ)``.

    Both take a single flat θ tensor (blocks ordered as ``names``). Frozen
    parameters (not in ``names``) are held fixed at their fitted values.
    """
    n = model.n
    obs = model.rn_obs

    # σ noise vector (Bq/m³). Default: σ_j = max(obs_j, detection_limit).
    sigma = _resolve_sigma(data, cfg)
    inv_sigma2 = tf.constant(1.0 / sigma ** 2, dtype=dtype)

    # Fixed (frozen) parameter values, used when a block is not being estimated.
    fixed = {
        "logI": tf.constant(np.log(np.asarray(result.inflow, float)), dtype=dtype),
        "logh": tf.constant(np.log(np.asarray(result.hz_depth, float)), dtype=dtype),
        "logth": tf.constant(np.log(np.asarray(result.residence_time, float)), dtype=dtype),
    }
    # Prior-anchor reference θ₀ = the fitted values (so the anchor is centred at MAP).
    theta0 = {k: tf.identity(v) for k, v in fixed.items()}

    def unpack(theta):
        """Split flat θ into (logI, logh, logth), filling frozen blocks from `fixed`."""
        out = dict(fixed)
        for j, name in enumerate(names):
            out[name] = theta[j * n:(j + 1) * n]
        return out["logI"], out["logh"], out["logth"]

    def model_C(theta):
        """Modelled nodal radon as a function of θ (differentiable)."""
        logI, logh, logth = unpack(theta)
        return model.solve(tf.exp(logI), tf.exp(logh), tf.exp(logth))

    def nlp(theta):
        """Negative log-posterior: ½·χ² (data) + ½·(smoothness + prior) terms."""
        C = model_C(theta)
        val = 0.5 * tf.reduce_sum(inv_sigma2 * (C - obs) ** 2)
        # Regularisation terms apply only to the *estimated* blocks.
        if cfg.smooth_weight > 0 or cfg.prior_weight > 0:
            logI, logh, logth = unpack(theta)
            active = {"logI": logI, "logh": logh, "logth": logth}
            for name in names:
                p = active[name]
                if cfg.smooth_weight > 0:
                    val = val + 0.5 * cfg.smooth_weight * tf.reduce_sum((p[1:] - p[:-1]) ** 2)
                if cfg.prior_weight > 0:
                    val = val + 0.5 * cfg.prior_weight * tf.reduce_sum((p - theta0[name]) ** 2)
        return val

    return nlp, model_C, inv_sigma2.numpy(), theta0


def posterior_covariance(data, result, config: UncertaintyConfig | None = None,
                         dtype=tf.float64) -> UncertaintyResult:
    """Compute the Laplace posterior covariance of the fitted parameters.

    Parameters
    ----------
    data : InputData
        The same parsed input used for the fit (``read_input``).
    result : ForwardResult
        The optimum returned by ``inverse.fit`` (the MAP point).
    config : UncertaintyConfig, optional
        Noise model, prior precisions, GN-vs-full Hessian, calibration.

    Returns
    -------
    UncertaintyResult
        Covariance (log + physical space), Hessian, per-reach std / credible
        intervals, and a ``summary()`` / ``correlation()`` helper.
    """
    cfg = config or UncertaintyConfig()
    model = TFModel(data, dtype=dtype)
    names = _active_blocks(data, cfg)
    n = model.n
    n_par = len(names) * n

    theta = _theta_at_optimum(data, result, names, dtype)
    nlp, model_C, inv_sigma2, _ = _make_nlp(model, data, result, cfg, names, dtype)

    # --- 1) Hessian of the negative log-posterior at θ̂ ------------------------
    if cfg.method == "full":
        # Exact second derivatives via two nested tapes: outer tape differentiates
        # the gradient produced by the inner tape (includes model curvature).
        with tf.GradientTape() as t2:
            t2.watch(theta)
            with tf.GradientTape() as t1:
                t1.watch(theta)
                val = nlp(theta)
            g = t1.gradient(val, theta)
        H = t2.jacobian(g, theta).numpy()
    elif cfg.method == "gauss_newton":
        # H ≈ Jᵀ Σ⁻¹ J  +  prior Hessian.  J = ∂C/∂θ  (N_obs × n_par).
        with tf.GradientTape() as tape:
            tape.watch(theta)
            C = model_C(theta)
        J = tape.jacobian(C, theta).numpy()
        H = J.T @ (inv_sigma2[:, None] * J)
        # Analytic Hessians of the (quadratic) regularisation terms.
        if cfg.smooth_weight > 0:
            D = _difference_operator(n)                       # (n-1 × n) per block
            DtD = D.T @ D
            for j in range(len(names)):
                sl = slice(j * n, (j + 1) * n)
                H[sl, sl] += cfg.smooth_weight * DtD
        if cfg.prior_weight > 0:
            H += cfg.prior_weight * np.eye(n_par)
    else:
        raise ValueError(f"unknown method {cfg.method!r} (use 'gauss_newton' or 'full')")

    # --- 2) Invert (with jitter) to get the covariance ------------------------
    H = H + cfg.jitter * np.eye(n_par)
    cov_log = np.linalg.inv(H)
    # Symmetrise to kill round-off asymmetry.
    cov_log = 0.5 * (cov_log + cov_log.T)

    # --- 3) Optional empirical noise rescaling s² = χ²/(N_obs − N_par) ---------
    sigma_scale = 1.0
    if cfg.calibrate_sigma:
        C = model_C(theta).numpy()
        chi2 = float(np.sum(inv_sigma2 * (C - model.rn_obs.numpy()) ** 2))
        dof = max(len(np.asarray(data.rn_obs)) - n_par, 1)
        sigma_scale = chi2 / dof
        cov_log = cov_log * sigma_scale

    theta_np = theta.numpy()

    # --- 4) Translate to physical space (delta method) & build per-reach blocks
    # CI z-score via the inverse error function (no scipy dependency):
    #   norm.ppf(0.5 + p/2) = sqrt(2)·erfinv(p)
    z = float(np.sqrt(2.0) * tf.math.erfinv(
        tf.constant(cfg.ci_level, dtype=tf.float64)).numpy())

    var_log = np.clip(np.diag(cov_log), 0.0, None)
    map_phys, std_phys, ci_low, ci_high = {}, {}, {}, {}
    for j, name in enumerate(names):
        sl = slice(j * n, (j + 1) * n)
        th = theta_np[sl]
        p = np.exp(th)                       # MAP in physical units
        s_log = np.sqrt(var_log[sl])         # 1σ in log space
        map_phys[name] = p
        std_phys[name] = p * s_log           # delta method: σ_p ≈ p · σ_logp
        ci_low[name] = np.exp(th - z * s_log)   # log-normal CI (always positive)
        ci_high[name] = np.exp(th + z * s_log)

    return UncertaintyResult(
        param_names=names, n_reaches=n, theta=theta_np,
        cov_log=cov_log, hessian=H,
        sigma_scale=sigma_scale, ci_level=cfg.ci_level,
        sigma=_resolve_sigma(data, cfg),
        map_phys=map_phys, std_phys=std_phys, ci_low=ci_low, ci_high=ci_high,
    )


def _difference_operator(n):
    """First-difference operator D (n-1 × n): (Dθ)_i = θ_{i+1} − θ_i."""
    D = np.zeros((n - 1, n))
    idx = np.arange(n - 1)
    D[idx, idx] = -1.0
    D[idx, idx + 1] = 1.0
    return D


# ---------------------------------------------------------------------------- #
# Identifiability diagnostics
# ---------------------------------------------------------------------------- #
def identifiability_report(unc: UncertaintyResult, n_modes: int = 5) -> str:
    """Eigen-analysis of the Hessian: which parameter directions are constrained.

    Small Hessian eigenvalues = large posterior variance = poorly-identified
    parameter *combinations*. For the radon problem these usually mix I, h and t_h
    on the same reach (the classic equifinality), which this report makes explicit.
    """
    H = unc.hessian
    evals, evecs = np.linalg.eigh(H)         # ascending eigenvalues
    cond = evals[-1] / max(evals[0], 1e-300)
    lines = [
        "Identifiability (Hessian eigen-spectrum)",
        f"  condition number κ(H) = {cond:.3e}",
        f"  {n_modes} least-constrained directions (smallest eigenvalues):",
    ]
    n = unc.n_reaches
    for m in range(min(n_modes, len(evals))):
        ev = evals[m]
        vec = evecs[:, m]
        # Which parameter block dominates this eigenvector?
        contrib = []
        for j, name in enumerate(unc.param_names):
            wnorm = np.linalg.norm(vec[j * n:(j + 1) * n])
            contrib.append(f"{name}:{wnorm:.2f}")
        lines.append(f"    λ={ev:.3e}  (posterior σ≈{1/np.sqrt(max(ev,1e-300)):.2e})  "
                     f"weight[{', '.join(contrib)}]")
    return "\n".join(lines)


# ---------------------------------------------------------------------------- #
# One-call convenience
# ---------------------------------------------------------------------------- #
def estimate_uncertainty(data, result, config: UncertaintyConfig | None = None,
                         dtype=tf.float64, verbose: bool = True) -> UncertaintyResult:
    """Fit-then-uncertainty convenience wrapper around :func:`posterior_covariance`."""
    unc = posterior_covariance(data, result, config, dtype=dtype)
    if verbose:
        print(unc.summary())
        print(identifiability_report(unc))
    return unc
