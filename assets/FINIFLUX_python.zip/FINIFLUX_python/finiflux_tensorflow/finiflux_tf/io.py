"""Reading FINIFLUX.xlsx and writing native-format outputs.

Framework-agnostic (NumPy + openpyxl only) — this file is essentially identical
to ``finiflux_torch/io.py`` so both ports read/write exactly the same files. It
mirrors the original ``FINIFLUX.xls`` layout (FINIFLUX_manual.pdf pp. 9-13) but
parses it *flexibly*: the problem size is taken from however many rows are filled,
so any number of observation nodes / reaches works, and the OPTIONS block is read
by label (not fixed cell address) so small row shifts do not break parsing.

Spreadsheet layout (single sheet)
---------------------------------
OPTIONS  : column B = label, column C = value (parsed by label, row-robust)
NODES    : column F = location [m], column G = measured Rn [Bq/m3]   (N_nodes rows)
REACHES  : columns I..T, one row per reach (N_reaches = N_nodes - 1 rows)
    I reach number, J length [m], K depth [m], L width [m],
    M GW endmember Rn [Bq/m3], N initial HZ depth [m], O porosity [-],
    P tributary discharge [m3/s], Q tributary/inflow length [m],
    R tributary Rn [Bq/m3], S discharge [m3/s], T user degassing k [m/s]
"""
from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np

# 222Rn radioactive decay constant [1/s] (half-life ~3.82 d; matches FINIFLUX.m).
LAMBDA_RN = 0.18 / 86400.0


@dataclass
class Options:
    """Scalar simulation options parsed from the OPTIONS block (cols B/C)."""
    degas_model: int = 1          # C8 : 1 O'Connor-Dobbins, 2 Negulescu-Rojanski, 3 user
    hz_on: bool = True            # C13: simulate hyporheic exchange (1) or not (0)
    rtd_model: int = 1            # C17: 1 exponential, 2 power-law, 3 gamma
    gamma_alpha: float = 1.0      # C22: shape parameter for the gamma RTD
    beta: float = 0.5             # C24: Petrov-Galerkin upstream weighting (0..1)
    detection_limit: float = 2.5  # radon detection limit [Bq/m3] (misfit weighting)
    lambda_rn: float = LAMBDA_RN  # decay constant [1/s]
    pl_exponent: float = 3.0      # power-law (Pareto) exponent (>2); only RTD model 2


@dataclass
class InputData:
    """Everything the forward model needs, as NumPy arrays.

    Nodal arrays have length ``n_nodes``; reach (element) arrays have length
    ``n_reaches = n_nodes - 1``.
    """
    # nodes
    x_node: np.ndarray            # [m]      location of each observation node (col F)
    rn_obs: np.ndarray            # [Bq/m3]  measured Rn at each node          (col G)
    # reaches (elements)
    dx: np.ndarray                # [m]      reach length                       (col J)
    depth: np.ndarray             # [m]      reach depth                        (col K)
    width: np.ndarray             # [m]      reach width                        (col L)
    cgw: np.ndarray               # [Bq/m3]  GW endmember Rn                    (col M)
    h0: np.ndarray                # [m]      initial guess HZ depth             (col N)
    por: np.ndarray               # [-]      streambed porosity                 (col O)
    qin: np.ndarray               # [m3/s]   tributary discharge (0 if none)    (col P)
    inflow_len: np.ndarray        # [m]      tributary inflow length (0 if none)(col Q)
    cin: np.ndarray               # [Bq/m3]  tributary Rn                       (col R)
    discharge: np.ndarray         # [m3/s]   reach discharge Q                  (col S)
    user_k: np.ndarray            # [m/s]    user degassing (degas_model == 3)  (col T)
    options: Options = field(default_factory=Options)
    cgw_sd: "np.ndarray | None" = None  # [Bq/m3] GW endmember std-dev (col U; optional)
    bedform_height: "np.ndarray | None" = None  # [m] bedform height H (col N) for the
                                                # Elliott-Brooks hyporheic-depth model

    @property
    def n_nodes(self) -> int:
        return int(self.x_node.shape[0])

    @property
    def n_reaches(self) -> int:
        return int(self.dx.shape[0])

    # ---- defaults for parameters that are *estimated* (no native column) ----
    def initial_inflow(self) -> np.ndarray:
        """Initial guess for reach groundwater inflow I [m3/(m s)].

        A small positive seed; consistent with the MATLAB+PEST workflow where I
        has no input column and is estimated entirely by the optimiser.
        """
        return np.full(self.n_reaches, 1e-6, dtype=float)

    def initial_residence_time(self) -> np.ndarray:
        """Initial guess for HZ mean residence time t_h [s] (~0.25 day).

        Kept below the default upper bound (0.5 day in FitConfig.th_bounds) so the
        initial value is not clamped at the very first iteration.
        """
        return np.full(self.n_reaches, 21600.0, dtype=float)


def _col(ws, letter, row0, n=None):
    """Read a worksheet column into a Python list.

    ``n is None`` -> auto-length: read until the first empty cell (node columns,
    whose length defines the problem size). ``n`` given -> fixed-length: read
    exactly ``n`` rows keeping blanks (reach columns, which must align 1:1 with
    the reaches and may legitimately contain 0/blank cells).
    """
    from openpyxl.utils import column_index_from_string
    ci = column_index_from_string(letter)
    vals, r = [], row0
    while True:
        v = ws.cell(row=r, column=ci).value
        if n is None:
            if v is None:           # auto-length: stop at the first gap
                break
            vals.append(v)
        else:
            vals.append(v)          # fixed-length: keep blanks (caller fills default)
            if len(vals) >= n:
                break
        r += 1
    return vals


def _read_options(ws) -> Options:
    """Parse the OPTIONS block by scanning column B labels (robust to row shifts).

    Rather than hard-coding cell addresses (C8, C13, …), we walk the label column
    and match on keywords, so the reader still works if rows are inserted/removed.
    """
    opt = Options()
    for r in range(1, 60):
        label = ws.cell(row=r, column=2).value
        value = ws.cell(row=r, column=3).value
        if label is None or value is None:
            continue
        t = str(label).lower()
        try:
            fv = float(value)
        except (TypeError, ValueError):
            continue                       # label row without a numeric value
        if "degas" in t:
            opt.degas_model = int(fv)
        elif "hyporheic" in t or "hyoprheic" in t:   # tolerate the manual's typo
            if "off" in t or "(0)" in t:
                opt.hz_on = bool(int(fv))
        elif "distribution" in t:
            opt.rtd_model = int(fv)
        elif "alpha" in t:
            opt.gamma_alpha = fv
        elif "upstream" in t:
            opt.beta = fv
        elif "detection" in t:
            opt.detection_limit = fv
    return opt


def read_input(path: str, data_row0: int = 4) -> InputData:
    """Read a FINIFLUX.xlsx workbook into an :class:`InputData`.

    Works for any number of nodes/reaches. ``data_row0`` is the first data row of
    the node/reach tables (4 in the shipped template).
    """
    import openpyxl
    # data_only=True returns cached cell values (not formulas).
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]               # FINIFLUX uses a single sheet
    opt = _read_options(ws)

    # Node table (cols F, G). The number of nodes is set by how many F-cells are
    # filled — this is what lets the reader adapt to any survey length.
    x_node = np.asarray(_col(ws, "F", data_row0), dtype=float)
    rn_obs = np.asarray(_col(ws, "G", data_row0)[: x_node.size], dtype=float)
    n_reaches = x_node.size - 1             # one fewer reach than nodes (manual)

    def reach_col(letter, default=0.0):
        """Read exactly ``n_reaches`` rows from a reach column, filling blanks."""
        raw = _col(ws, letter, data_row0, n=n_reaches)
        return np.asarray([default if v is None else float(v) for v in raw], dtype=float)

    # Optional per-reach GW endmember standard deviation (col U). Absent in older
    # templates -> None (the endmember-uncertainty analysis is then unavailable).
    cgw_sd_raw = _col(ws, "U", data_row0, n=n_reaches)
    cgw_sd = (None if all(v is None for v in cgw_sd_raw)
              else np.asarray([0.0 if v is None else float(v) for v in cgw_sd_raw], float))

    # Column N also read as the per-reach bedform height H (blank -> 0 = no bedform)
    # for the Elliott-Brooks hyporheic-depth model; shares the column with the
    # legacy HZ-depth initial guess h0 (ignored in bedform mode).
    bedform_height = reach_col("N", default=0.0)

    data = InputData(
        x_node=x_node, rn_obs=rn_obs,
        dx=reach_col("J"), depth=reach_col("K"), width=reach_col("L"),
        cgw=reach_col("M"), h0=reach_col("N", 0.1), por=reach_col("O", 0.3),
        qin=reach_col("P"), inflow_len=reach_col("Q"), cin=reach_col("R"),
        discharge=reach_col("S"), user_k=reach_col("T"), options=opt, cgw_sd=cgw_sd,
        bedform_height=bedform_height,
    )
    _validate(data)
    return data


def _validate(data: InputData) -> None:
    """Sanity-check array lengths and node ordering, with clear error messages."""
    n = data.n_reaches
    # Every reach column must have exactly one value per reach.
    for name in ("dx", "depth", "width", "cgw", "h0", "por", "qin",
                 "inflow_len", "cin", "discharge", "user_k"):
        if getattr(data, name).shape[0] != n:
            raise ValueError(f"reach column '{name}' length != {n}")
    if data.rn_obs.shape[0] != data.n_nodes:
        raise ValueError("measured Rn (col G) length must equal number of nodes")
    if np.any(np.diff(data.x_node) <= 0):
        raise ValueError("node locations (col F) must be strictly increasing")
    # Reach length (col J) should match node spacing; tributary rows legitimately
    # differ (a 1 m inflow element), so warn rather than fail and trust col J.
    if not np.allclose(np.diff(data.x_node), data.dx, rtol=1e-3, atol=1.0):
        import warnings
        warnings.warn("reach length (col J) != node spacing; using col J.")


# --------------------------------------------------------------------------- #
# Output writers (native FINIFLUX file names)
# --------------------------------------------------------------------------- #
def write_results(out_dir: str, data: InputData, result) -> None:
    """Write the four native FINIFLUX output files into ``out_dir``.

    gw_inflow.dat   estimated groundwater inflow rate I per reach  [m3/(m s)]
    depth_hz.dat    estimated hyporheic-zone depth h per reach     [m]
    rtimes_hz.dat   estimated hyporheic mean residence time t_h    [s]
    Rn_modeled.csv  node location [m] and modelled radon [Bq/m3] (tab-separated)
    """
    import os
    os.makedirs(out_dir, exist_ok=True)
    np.savetxt(os.path.join(out_dir, "gw_inflow.dat"), result.inflow)
    np.savetxt(os.path.join(out_dir, "depth_hz.dat"), result.hz_depth)
    np.savetxt(os.path.join(out_dir, "rtimes_hz.dat"), result.residence_time)
    arr = np.column_stack([data.x_node, result.rn_model])
    np.savetxt(os.path.join(out_dir, "Rn_modeled.csv"), arr,
               delimiter="\t", fmt="%.16g")
