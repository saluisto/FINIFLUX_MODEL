"""Autodiff inverse model (TensorFlow).

TensorFlow twin of ``finiflux_torch/inverse.py``. It replaces the external
BEOPEST optimiser: because the forward model (``forward.TFModel.solve``) is
differentiable, a ``tf.GradientTape`` gives the gradient of the data-misfit
w.r.t. the unknowns and we drive Adam directly.

Estimated, per reach:
    I    groundwater inflow rate        [m³/(m·s)]
    h    hyporheic-zone depth           [m]
    t_h  hyporheic mean residence time  [s]

Design choices (identical to the PyTorch port)
----------------------------------------------
* **Log-space parameters** for strict positivity and better scaling.
* **Normalised misfit** weighted by ``1/max(obs, det_limit)²`` so low/high nodes
  contribute comparably and sub-detection values are down-weighted.
* **Optional regularisation**: a smoothness penalty on log-parameters across
  reaches (``smooth_weight``) and an optional prior anchor (``prior_weight``),
  both defaulting small/zero so the data drive the fit.
* **Optimiser**: Adam (TF/Keras). PyTorch additionally uses L-BFGS; TF's Keras
  optimisers are first-order, so we run Adam for more iterations here.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import tensorflow as tf

from .forward import TFModel, ForwardResult


@dataclass
class FitConfig:
    """All knobs for the inversion (sensible defaults; override as needed)."""
    estimate_h: bool = True          # estimate hyporheic depth? (ignored if HZ off)
    estimate_th: bool = True         # estimate residence time?  (ignored if HZ off)
    use_bedform_depth: bool = False  # compute h from bedforms (Elliott-Brooks) instead
                                     # of estimating it -> h fixed, only I & t_h fitted
    n_iter: int = 600                # Adam iterations
    lr: float = 0.05                 # Adam learning rate (in log-parameter space)
    smooth_weight: float = 1e-3      # μ_s: penalises Δ(logθ) between adjacent reaches
    prior_weight: float = 0.0        # μ_p: anchors logθ toward initial values (optional)
    # Physical bounds (clamped in log-space each evaluation).
    i_bounds: tuple = (1e-10, 1e-2)    # groundwater inflow I  [m³/(m·s)]
    h_bounds: tuple = (1e-3, 10.0)      # hyporheic depth h      [m]   (upper = 1 m)
    th_bounds: tuple = (60.0, 10*86400.0) # residence time t_h     [s]   (upper = 10.0 day)


def _weights(rn_obs, det_limit):
    """Per-node least-squares weights: inverse-square of the (clipped) observation.

    Turns each squared residual into a relative error so a fixed Bq/m³ miss counts
    equally at hot and cold nodes, and sub-detection values cannot dominate.
    """
    return 1.0 / np.maximum(rn_obs, det_limit) ** 2


def fit(data, config: FitConfig | None = None, dtype=tf.float64,
        verbose: bool = True) -> ForwardResult:
    """Estimate I, h, t_h by gradient-based minimisation of the radon misfit."""
    cfg = config or FitConfig()
    model = TFModel(data, dtype=dtype)
    hz = data.options.hz_on

    # Hyporheic depth: estimated (legacy) or computed from the Elliott-Brooks
    # bedform head relation. In bedform mode h is deterministic -> frozen, unclamped.
    if cfg.use_bedform_depth:
        from .bedform import hyporheic_depth_from_bedforms
        h_init = hyporheic_depth_from_bedforms(data)
        estimate_h = False
    else:
        h_init = np.asarray(data.h0, float)
        estimate_h = cfg.estimate_h

    # Log-space parameters as tf.Variables. h and t_h are frozen (trainable=False)
    # when hyporheic exchange is off or the caller disables them, so Adam leaves
    # them at their priors.
    logI = tf.Variable(np.log(data.initial_inflow()), dtype=dtype)
    logh = tf.Variable(np.log(h_init), dtype=dtype,
                       trainable=estimate_h and hz)
    logth = tf.Variable(np.log(data.initial_residence_time()), dtype=dtype,
                        trainable=cfg.estimate_th and hz)
    # Snapshot priors for the optional prior-anchor regularisation term.
    logI0 = tf.constant(logI.numpy(), dtype=dtype)
    logh0 = tf.constant(logh.numpy(), dtype=dtype)
    logth0 = tf.constant(logth.numpy(), dtype=dtype)

    obs = model.rn_obs
    w = tf.constant(_weights(data.rn_obs, data.options.detection_limit), dtype=dtype)

    def clamp(v, lo, hi):
        """Clamp a log-parameter to its physical [lo, hi] range (in log units)."""
        return tf.clip_by_value(v, np.log(lo), np.log(hi))

    def loss_fn():
        """Scalar objective = weighted misfit + regularisation."""
        # Map log-params back to physical units (with bounds) and run the model.
        # Bedform-computed h is used as-is (deterministic, not clamped).
        I = tf.exp(clamp(logI, *cfg.i_bounds))
        h = tf.exp(logh) if cfg.use_bedform_depth else tf.exp(clamp(logh, *cfg.h_bounds))
        th = tf.exp(clamp(logth, *cfg.th_bounds))
        C = model.solve(I, h, th)

        # Data term: normalised sum of squared residuals at observation nodes.
        misfit = tf.reduce_sum(w * (C - obs) ** 2)

        reg = tf.constant(0.0, dtype=dtype)
        # Smoothness: penalise jumps in each log-parameter between adjacent reaches.
        if cfg.smooth_weight > 0:
            for p in (logI, logh, logth):
                reg += cfg.smooth_weight * tf.reduce_sum((p[1:] - p[:-1]) ** 2)
        # Prior anchor: pull parameters toward their initial values (optional).
        if cfg.prior_weight > 0:
            reg += cfg.prior_weight * (
                tf.reduce_sum((logI - logI0) ** 2)
                + tf.reduce_sum((logh - logh0) ** 2)
                + tf.reduce_sum((logth - logth0) ** 2))
        return misfit + reg

    # Only optimise the trainable variables (frozen ones are excluded).
    variables = [v for v in (logI, logh, logth) if v.trainable]
    opt = tf.keras.optimizers.Adam(learning_rate=cfg.lr)
    for it in range(cfg.n_iter):
        # Record ops on the tape, get gradients, apply one Adam step.
        with tf.GradientTape() as tape:
            loss = loss_fn()
        grads = tape.gradient(loss, variables)
        opt.apply_gradients(zip(grads, variables))
        if verbose and it % max(1, cfg.n_iter // 10) == 0:
            print(f"[adam {it:4d}] loss = {float(loss):.6e}")
    if verbose:
        print(f"[end] loss = {float(loss_fn()):.6e}")

    # --- final evaluation at the optimum (convert to NumPy for the result) ---
    I = tf.exp(clamp(logI, *cfg.i_bounds)).numpy()
    h = (tf.exp(logh) if cfg.use_bedform_depth
         else tf.exp(clamp(logh, *cfg.h_bounds))).numpy()
    th = tf.exp(clamp(logth, *cfg.th_bounds)).numpy()
    C = model.solve(tf.constant(I, dtype), tf.constant(h, dtype),
                    tf.constant(th, dtype)).numpy()
    return ForwardResult(rn_model=C, inflow=I, hz_depth=h, residence_time=th)


def run_forward(data, inflow=None, hz_depth=None, residence_time=None,
                dtype=tf.float64) -> ForwardResult:
    """Run the forward model once with given (or default/prior) parameters.

    Useful for inspecting the starting point or generating synthetic data in a
    twin experiment. Parameters left as ``None`` fall back to the input-file /
    default priors.
    """
    model = TFModel(data, dtype=dtype)
    I = tf.constant(data.initial_inflow() if inflow is None else np.asarray(inflow, float), dtype)
    h = tf.constant(np.asarray(data.h0 if hz_depth is None else hz_depth, float), dtype)
    th = tf.constant(
        data.initial_residence_time() if residence_time is None else np.asarray(residence_time, float),
        dtype)
    C = model.solve(I, h, th).numpy()
    return ForwardResult(C, I.numpy(), h.numpy(), th.numpy())
