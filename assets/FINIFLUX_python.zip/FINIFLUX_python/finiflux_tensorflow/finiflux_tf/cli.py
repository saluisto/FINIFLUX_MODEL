"""Command-line entry point for the TensorFlow FINIFLUX port.

Two sub-commands:

* ``forward`` - run the radon forward model once with the initial parameters.
* ``invert``  - estimate the reach-specific groundwater inflow ``I``, hyporheic
  depth ``h`` and mean residence time ``t_h`` by autodiff, then write the native
  output files and the diagnostic plots.

Examples
--------
    python -m finiflux_tf.cli forward FINIFLUX.xlsx --out results_fwd
    python -m finiflux_tf.cli invert  FINIFLUX.xlsx --out results
    python -m finiflux_tf.cli invert  FINIFLUX.xlsx --out results --plot fit.png

By default a combined diagnostic figure (radon fit, estimated parameters,
cumulative groundwater inflow) is written to ``<out>/finiflux_plots.png``. Pass
``--plot PATH`` to choose a different file, or ``--no-plot`` to skip plotting.
"""
from __future__ import annotations

import argparse
import os

from . import io as fio
from . import inverse as finv


def _add_common(sp):
    """Arguments shared by both sub-commands."""
    sp.add_argument("xlsx", help="path to the FINIFLUX.xlsx input file")
    sp.add_argument("--out", default="results", help="output directory")
    sp.add_argument("--plot", default=None,
                    help="figure path (default: <out>/finiflux_plots.png)")
    sp.add_argument("--no-plot", action="store_true", help="skip plotting")


def main(argv=None):
    p = argparse.ArgumentParser(prog="finiflux_tf")
    sub = p.add_subparsers(dest="cmd", required=True)

    pf = sub.add_parser("forward", help="run the forward model once")
    _add_common(pf)

    pi = sub.add_parser("invert", help="estimate I, h, t_h by autodiff")
    _add_common(pi)
    pi.add_argument("--iter", type=int, default=600, help="Adam iterations")
    pi.add_argument("--lr", type=float, default=0.05, help="Adam learning rate")
    pi.add_argument("--smooth", type=float, default=1e-3,
                    help="smoothness regularisation weight")
    pi.add_argument("--quiet", action="store_true", help="suppress progress output")

    args = p.parse_args(argv)
    data = fio.read_input(args.xlsx)

    # --- run model ---------------------------------------------------------- #
    if args.cmd == "forward":
        result = finv.run_forward(data)
    else:
        cfg = finv.FitConfig(n_iter=args.iter, lr=args.lr, smooth_weight=args.smooth)
        result = finv.fit(data, cfg, verbose=not args.quiet)

    # --- native output files ----------------------------------------------- #
    fio.write_results(args.out, data, result)
    print(f"wrote outputs to {args.out}/ "
          "(gw_inflow.dat, depth_hz.dat, rtimes_hz.dat, Rn_modeled.csv)")

    # --- diagnostic plots --------------------------------------------------- #
    if not args.no_plot:
        plot_path = args.plot or os.path.join(args.out, "finiflux_plots.png")
        from .plotting import plot_all
        plot_all(data, result, path=plot_path)
        print(f"wrote diagnostic plots to {plot_path}")


if __name__ == "__main__":
    main()
