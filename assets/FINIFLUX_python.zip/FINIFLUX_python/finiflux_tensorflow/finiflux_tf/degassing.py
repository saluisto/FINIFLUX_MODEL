"""Gas-evasion (degassing) coefficient ``k`` per reach (TensorFlow).

Radon is volatile, so it escapes from the stream surface to the atmosphere — a
sink in the mass balance, entering as ``k * w`` (gas-transfer velocity × width).
FINIFLUX offers two empirical reaeration models plus a user-supplied option
(OPTIONS C8 selects which one). Both empirical formulas were calibrated with the
flow velocity expressed in **m/day**, so we convert ``v`` to m/day for the
formula and convert the resulting ``k`` back to **m/s** to stay in SI for the
rest of the model.

Velocity:  ``v = (Q / A) * 86400``  [m/day],  with cross-section ``A = depth*width``.
The ``* depth / 86400`` factors at the end turn the empirical gas-exchange rate
into a transfer velocity in m/s. This mirrors FINIFLUX.m line-for-line and is the
TensorFlow twin of ``finiflux_torch/degassing.py``.
"""
from __future__ import annotations

import tensorflow as tf


def gas_coefficient(model: int, Q, depth, width, user_k):
    """Return per-reach degassing coefficient ``k`` [m/s] as a tf tensor.

    Parameters
    ----------
    model : int
        OPTIONS C8: 1 = O'Connor & Dobbins (1958), 2 = Negulescu & Rojanski
        (1969), 3 = user-defined values supplied in column T.
    Q, depth, width : tf.Tensor
        Per-reach discharge [m³/s], depth [m] and width [m].
    user_k : tf.Tensor
        Per-reach user values [m/s] (only used when ``model == 3``).
    """
    area = depth * width             # channel cross-sectional area A [m²]
    v = (Q / area) * 86400.0         # mean flow velocity [m/day] for the empirical fits
    if model == 1:                     # O'Connor & Dobbins (1958): k ∝ v^0.5 / depth^1.5
        k = (9.301e-3 * tf.sqrt(v) / depth ** 1.5) * depth / 86400.0
    elif model == 2:                   # Negulescu & Rojanski (1969): k ∝ (v/depth)^0.85
        k = (4.87e-4 * (v / depth) ** 0.85) * depth / 86400.0
    elif model == 3:                   # user-measured/specified gas-transfer velocities
        k = tf.identity(user_k)
    else:
        raise ValueError(f"unknown degassing model {model}")
    return k
