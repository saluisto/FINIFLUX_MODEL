"""Differentiable steady-state radon forward model (TensorFlow).

TensorFlow twin of ``finiflux_torch/forward.py`` — identical physics and
numerics, only the tensor backend differs. It solves the steady-state ²²²Rn mass
balance along a 1-D stream (as in the original ``FINIFLUX.m``) using
differentiable ops, so gradients of the modelled radon w.r.t. the unknowns
(``I``, ``h``, ``t_h``) are available via ``tf.GradientTape`` for the inversion.

Physics (steady state, one reach)
---------------------------------
    Q dC/dx = [ I·c_gw + α1 + (Qin/L)·cin ]                (sources, "P")
            - [ I + α2 + k·w + λ·d·w + Qin/L ] · C         (sinks ∝ C, "S")

where I = groundwater inflow, c_gw = GW radon endmember, α1/α2 = hyporheic
production/loss (see hyporheic.py), k = degassing velocity (see degassing.py),
w/d = width/depth, λ = ²²²Rn decay constant, and Qin/L/cin describe tributary
inflow.

Numerics
--------
Linear (P1) finite elements: each reach contributes a 2×2 element matrix
(consistent reaction + Galerkin advection) plus a Petrov-Galerkin upstream
correction (weighted by ``beta`` = OPTIONS C24). Contributions are scattered into
a global system with ``tf.scatter_nd``, the upstream Dirichlet BC is imposed by
the penalty trick, and ``tf.linalg.solve`` solves ``A C = b``. Every step is a tf
op, so ``C`` is differentiable w.r.t. ``I``, ``h`` and ``t_h``.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import tensorflow as tf

from .degassing import gas_coefficient
from .hyporheic import hyporheic_terms

# Petrov-Galerkin scaling constant, fixed at 0.75 in FINIFLUX.m. The effective
# amount of upwinding is this times ``beta`` (the user-set OPTIONS C24 weight).
_ALP = 0.75


@dataclass
class ForwardResult:
    """Container for a single model evaluation (plain NumPy, framework-neutral)."""
    rn_model: np.ndarray        # modelled radon at the nodes         [Bq/m³]
    inflow: np.ndarray          # groundwater inflow rate I per reach [m³/(m·s)]
    hz_depth: np.ndarray        # hyporheic-zone depth h per reach     [m]
    residence_time: np.ndarray  # hyporheic mean residence time t_h    [s]


class TFModel:
    """Pre-builds the constant reach data as tensors; ``solve`` runs the FE model.

    Everything that does not depend on the estimated parameters (geometry,
    discharge, assembly index maps, the upstream BC value) is converted to
    constants once in ``__init__`` so the per-iteration ``solve`` stays cheap.
    """

    def __init__(self, data, dtype=tf.float64):
        self.data = data
        self.opt = data.options          # parsed OPTIONS block (degas model, RTD, beta, …)
        self.dtype = dtype               # float64: the FE solve is ill-conditioned

        # Helper: array-like -> constant tensor of the chosen dtype.
        c = lambda a: tf.constant(np.asarray(a, float), dtype=dtype)

        # --- constant per-reach geometry & forcing (one value per reach) ---
        self.dx = c(data.dx)             # reach length            [m]   (col J)
        self.depth = c(data.depth)       # reach depth             [m]   (col K)
        self.width = c(data.width)       # reach width             [m]   (col L)
        self.cgw = c(data.cgw)           # GW radon endmember      [Bq/m³] (col M)
        self.por = c(data.por)           # streambed porosity      [-]   (col O)
        self.qin = c(data.qin)           # tributary discharge     [m³/s] (col P)
        self.cin = c(data.cin)           # tributary radon         [Bq/m³] (col R)
        self.Q = c(data.discharge)       # reach discharge Q       [m³/s] (col S)
        self.user_k = c(data.user_k)     # user degassing k        [m/s]  (col T)

        # Tributary inflow length L appears as Qin/L; where there is no tributary
        # the length is 0, so replace those with 1 (Qin is 0 there anyway), as in
        # FINIFLUX.m.
        rl = np.where(data.inflow_len == 0, 1.0, data.inflow_len)
        self.rl = c(rl)

        self.lam = float(self.opt.lambda_rn)   # decay constant λ  [1/s]
        self.n = data.n_reaches                # number of reaches (elements)
        self.N = data.n_nodes                  # number of nodes = n_reaches + 1
        self.rn_obs = c(data.rn_obs)           # measured radon at nodes (col G)

        # --- assembly index maps (constant; depend only on the mesh) ---
        # Reach i couples nodes i and i+1, contributing four matrix entries
        # (i,i), (i,i+1), (i+1,i), (i+1,i+1). scatter_nd needs (row,col) pairs.
        i = np.arange(self.n)
        self.A_idx = tf.constant(
            np.stack([np.concatenate([i, i, i + 1, i + 1]),
                      np.concatenate([i, i + 1, i, i + 1])], axis=1),
            dtype=tf.int32)
        # Load-vector entries land on nodes i and i+1 (column vector of indices).
        self.b_idx = tf.constant(
            np.concatenate([i, i + 1])[:, None], dtype=tf.int32)

    def solve(self, inflow, hz_depth, residence_time):
        """Assemble and solve the FE system for the nodal radon profile.

        Call inside a ``tf.GradientTape`` (watching ``inflow``/``hz_depth``/
        ``residence_time``) to obtain gradients. Returns the nodal radon tensor
        of length ``n_reaches + 1``.
        """
        d, w, Q, dx = self.depth, self.width, self.Q, self.dx
        lam, beta = self.lam, float(self.opt.beta)

        # 1) Degassing coefficient k [m/s] per reach (empirical or user-supplied).
        k = gas_coefficient(self.opt.degas_model, Q, d, w, self.user_k)

        # 2) Hyporheic source (α1) and loss (α2) terms; zero when HZ is off (C13=0).
        if self.opt.hz_on:
            a1, a2 = hyporheic_terms(
                hz_depth, residence_time, self.cgw, w, self.por, lam,
                self.opt.rtd_model, self.opt.gamma_alpha, self.opt.pl_exponent,
                self.dtype)
        else:
            a1 = tf.zeros_like(dx)
            a2 = tf.zeros_like(dx)

        # 3) Lump the reaction (sink) coefficient S and the source load P per reach.
        trib = self.qin / self.rl
        S = inflow + a2 + k * w + lam * d * w + trib            # sinks ∝ C
        P = inflow * self.cgw + a1 + trib * self.cin            # sources

        # 4) Element matrix entries: consistent reaction S*dx*[[1/3,1/6],[1/6,1/3]]
        #    plus Galerkin advection Q*[[-1/2,1/2],[-1/2,1/2]] (same as FINIFLUX.m).
        e00 = S * dx / 3.0 - Q / 2.0
        e01 = S * dx / 6.0 + Q / 2.0
        e10 = S * dx / 6.0 - Q / 2.0
        e11 = S * dx / 3.0 + Q / 2.0

        # 5) Petrov-Galerkin upstream correction (artificial upwind diffusion,
        #    scaled by beta*ALP). Vanishes when beta = 0 (pure Galerkin).
        ba = beta * _ALP / 3.0
        c00 = ba * (2.0 * Q - S * dx)
        c01 = -ba * (2.0 * Q + S * dx)
        c10 = -ba * (2.0 * Q - S * dx)
        c11 = ba * (2.0 * Q + S * dx)

        # Flatten the four corrected entries per reach to match self.A_idx ordering.
        a_vals = tf.concat([e00 + c00, e01 + c01, e10 + c10, e11 + c11], axis=0)

        # 6) Load vector: consistent source S*dx*[1/2,1/2] plus its upwind correction.
        v_half = P * dx / 2.0
        cv = (2.0 * beta / 3.0) * P * dx
        b_vals = tf.concat([v_half - cv, v_half + cv], axis=0)

        # 7) Scatter element contributions into the global system. scatter_nd sums
        #    duplicate indices, so shared nodes accumulate adjacent reaches correctly.
        A = tf.scatter_nd(self.A_idx, a_vals, shape=[self.N, self.N])
        b = tf.scatter_nd(self.b_idx, b_vals, shape=[self.N])

        # 8) Upstream Dirichlet BC: fix C at node 0 to the first measured radon
        #    value via the penalty trick (×1e6 on the (0,0) diagonal). Done with
        #    one-hot algebra (no in-place writes) to keep autodiff happy.
        c_bc = self.rn_obs[0]
        a00 = A[0, 0]
        pen = a00 * 1.0e6
        e0 = tf.one_hot(0, self.N, dtype=self.dtype)
        A = A + tf.tensordot(e0, e0, axes=0) * (pen - a00)     # overwrite only (0,0)
        b = b * (1.0 - e0) + e0 * (pen * c_bc)                 # overwrite only b[0]

        # 9) Solve the dense linear system (tf.linalg.solve wants a column RHS).
        C = tf.linalg.solve(A, b[:, None])[:, 0]
        return C
