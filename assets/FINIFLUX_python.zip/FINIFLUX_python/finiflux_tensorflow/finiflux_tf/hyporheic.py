"""Hyporheic-zone radon source/sink terms (TensorFlow, differentiable).

The hyporheic zone (HZ) is the saturated sediment under/around the channel where
stream water briefly detours, ages, and returns. Because that water is shielded
from the atmosphere, ²²²Rn produced by the sediment accumulates, so returning
water is radon-enriched — a source term in the in-stream balance.

Derivation (consistent with FINIFLUX.m exponential case and pwr.m)
-----------------------------------------------------------------
A parcel of stream water with activity ``C`` enters the HZ, gains radon by
production ``gamma = c_gw * lambda`` and loses it by radioactive decay ``lambda``.
After residing a time ``t`` it returns carrying

    C_hz(t) = c_gw * (1 - e^{-lambda t}) + C * e^{-lambda t}     (gamma/lambda = c_gw)

Real reaches contain a distribution of path lengths, so ``t`` is random with a
residence-time distribution (RTD) ``p(t)``. Averaging ``e^{-lambda t}`` over the
RTD is its Laplace transform at ``lambda``:

    L(lambda) = E[e^{-lambda t}] = ∫_0^∞ e^{-lambda t} p(t) dt

With HZ exchange per unit length ``q_hz = h * w * por / t_h`` the net HZ→stream
radon flux per unit length is ``q_hz * (1 - L) * (c_gw - C)``, i.e.

    alpha2 = q_hz * (1 - L)        (loss coefficient, multiplies C)
    alpha1 = alpha2 * c_gw         (production term)

Exponential RTD has ``L = 1/(1 + lambda*t_h)`` and reproduces FINIFLUX.m exactly.
This is the TensorFlow twin of ``finiflux_torch/hyporheic.py``; both expose the
same (alpha1, alpha2) interface and are differentiable in ``h`` and ``t_h``.
"""
from __future__ import annotations

import numpy as np
import tensorflow as tf

# Fixed dimensionless quadrature grid for the power-law RTD integral. We integrate
# in the rescaled variable u = t / t_h (so the grid is t_h-independent and built
# once). _DU are the spacing weights for the Riemann/midpoint sum.
_U = np.logspace(-4, 5, 400)
_DU = np.gradient(_U)


def _laplace_powerlaw(lam_th, exponent: float, dtype):
    """Laplace transform of a mean-normalised shifted-Pareto (power-law) RTD.

    pdf in u = t/t_h:  p(u) = (p-1) c^{p-1} / (u + c)^p,  c = p - 2  ⇒ mean(u) = 1.
    Choosing c = p-2 makes the dimensional mean residence time exactly t_h, so the
    transform depends only on ``lam_th = lambda * t_h``.
    """
    p = float(exponent)
    c = p - 2.0
    u = tf.constant(_U, dtype=dtype)
    du = tf.constant(_DU, dtype=dtype)
    pdf = (p - 1.0) * c ** (p - 1.0) / (u + c) ** p          # shifted-Pareto pdf
    norm = tf.reduce_sum(pdf * du)                           # ~1; divide out grid error
    expo = tf.exp(-lam_th[:, None] * u[None, :])             # (n_reach, n_grid)
    return tf.reduce_sum(expo * (pdf * du)[None, :], axis=1) / norm


def laplace_transform(rtd_model, lam, t_h, gamma_alpha, pl_exponent, dtype):
    """RTD Laplace transform ``L(lambda)`` per reach (OPTIONS C17 selects the RTD)."""
    lam_th = lam * t_h                       # dimensionless decay-over-residence
    if rtd_model == 1:                       # exponential: closed form
        return 1.0 / (1.0 + lam_th)
    if rtd_model == 3:                       # gamma (shape a, mean t_h): closed form
        a = float(gamma_alpha)               # OPTIONS C22 shape parameter
        return (1.0 + lam_th / a) ** (-a)
    if rtd_model == 2:                       # power law: numerical quadrature
        return _laplace_powerlaw(lam_th, pl_exponent, dtype)
    raise ValueError(f"unknown RTD model {rtd_model}")


def hyporheic_terms(h, t_h, cgw, width, por, lam, rtd_model,
                    gamma_alpha=1.0, pl_exponent=3.0, dtype=tf.float64):
    """Return per-reach hyporheic production/loss terms ``(alpha1, alpha2)``.

    ``alpha2`` multiplies ``C`` in the in-stream sink term; ``alpha1`` is the
    constant radon production. Both are differentiable w.r.t. ``h`` and ``t_h``.
    """
    q_hz = h * width * por / t_h                                   # HZ exchange per length
    L = laplace_transform(rtd_model, lam, t_h, gamma_alpha, pl_exponent, dtype)
    alpha2 = q_hz * (1.0 - L)                                      # loss ∝ C
    alpha1 = alpha2 * cgw                                          # production
    return alpha1, alpha2
